// Build placeholder. build.mjs replaces this module with freshly generated worklets.
export const monoProcessorSource = "";
export const polyProcessorSource = "";
export const fftProcessorSource = "";
