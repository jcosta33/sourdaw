// Reconstructed by Sourdaw from the distributed0.20.2 worklet's dependency injection call.
import getFaustAudioWorkletProcessor from '../FaustAudioWorkletProcessor';
import { FaustAudioWorkletProcessorCommunicator } from '../FaustAudioWorkletCommunicator';
import FaustWasmInstantiator from '../FaustWasmInstantiator';
import { FaustBaseWebAudioDsp, FaustMonoWebAudioDsp, FaustPolyWebAudioDsp, FaustWebAudioDspVoice } from '../FaustWebAudioDsp';
declare const faustData: any;
getFaustAudioWorkletProcessor({ FaustBaseWebAudioDsp, FaustMonoWebAudioDsp: undefined, FaustPolyWebAudioDsp, FaustWebAudioDspVoice, FaustWasmInstantiator, FaustAudioWorkletProcessorCommunicator }, faustData);
