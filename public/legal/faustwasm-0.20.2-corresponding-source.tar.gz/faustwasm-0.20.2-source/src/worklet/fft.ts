// Reconstructed by Sourdaw from the distributed0.20.2 worklet's dependency injection call.
import getFaustFFTAudioWorkletProcessor from '../FaustFFTAudioWorkletProcessor';
import { FaustAudioWorkletProcessorCommunicator } from '../FaustAudioWorkletCommunicator';
import FaustWasmInstantiator from '../FaustWasmInstantiator';
import { FaustBaseWebAudioDsp, FaustMonoWebAudioDsp, FaustPolyWebAudioDsp, FaustWebAudioDspVoice } from '../FaustWebAudioDsp';
declare const faustData: any;
declare const FFTUtils: any;
getFaustFFTAudioWorkletProcessor({ FaustBaseWebAudioDsp, FaustMonoWebAudioDsp, FaustWasmInstantiator, FaustAudioWorkletProcessorCommunicator, FFTUtils }, faustData);
