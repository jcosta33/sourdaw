import type {
    FaustMonoDspInstance,
    FaustPolyDspInstance,
    IFaustDspInstance
} from './FaustDspInstance';
import type {
    AudioData,
    FaustDspMeta,
    FaustUIDescriptor,
    FaustUIGroup,
    FaustUIInputItem,
    FaustUIItem,
    LooseFaustDspFactory
} from './types';
import FaustSensors, {
    Axis,
    Curve,
    UpdatableValueConverter
} from './FaustSensors';

// Public API
export type OutputParamHandler = (path: string, value: number) => void;
export type InputParamHandler = (path: string, value: number) => void;
export type ComputeHandler = (buffer_size: number) => void;
export type PlotHandler = (
    plotted: Float32Array[] | Float64Array[],
    index: number,
    events?: { type: string; data: any }[]
) => void;
export type MetadataHandler = (key: string, value: string) => void;
export type NonFiniteHandler = () => void;
/** Receives the number of voices still sounding when it changes. */
export type ActiveVoicesHandler = (count: number) => void;

/**
 * A control write due at a known frame inside the next block.
 *
 * Given a list of these, `compute` renders the block in slices: up to the
 * frame of the next event, apply it, carry on. The same approach as
 * `architecture/faust/dsp/timed-dsp.h`, which is how a native host gets
 * sample-accurate MIDI.
 *
 * `apply` is a closure rather than a `{ path, value }` pair so one list can
 * carry parameter writes, `keyOn`s and MIDI messages together. The caller
 * knows how to perform each; the DSP only needs to know when.
 *
 * The list must be sorted by frame. Frames outside the block are clamped.
 */
export interface FaustTimedEvent {
    /** Frame offset from the start of the block, 0 <= frame < bufferSize */
    frame: number;
    /** Performed just before the slice starting at `frame` is rendered */
    apply: () => void;
}

// Implementation API
export type UIHandler = (item: FaustUIItem) => void;

// Accelerometer or gyroscope handler
export type SensorEventHandler = (val: number) => void;

// Define a type for the accelerometer or gyroscope handlers
export type SensorEventHandlers = {
    x: SensorEventHandler[];
    y: SensorEventHandler[];
    z: SensorEventHandler[];
};

/** Definition of the AudioBufferItem type */
export interface AudioBufferItem {
    pathName: string;
    audioBuffer: AudioBuffer;
}

/** Definition of the SoundfileItem type */
export interface SoundfileItem {
    /** Name of the soundfile */
    name: string;
    /** URL of the soundfile */
    url: string;
    /** Index in the DSP struct */
    index: number;
    /** Base pointer in wasm memory */
    basePtr: number;
}

/**
 * WasmAllocator is a basic memory management class designed to allocate
 * blocks of memory within a WebAssembly.Memory object. It provides a simple
 * alloc method to allocate a contiguous block of memory of a specified size.
 *
 * The allocator operates by keeping a linear progression through the memory,
 * always allocating the next block at the end of the last. This approach does not
 * handle freeing of memory or reuse of memory spaces.
 */
export class WasmAllocator {
    // The WebAssembly.Memory object this allocator will manage.
    private readonly memory: WebAssembly.Memory;
    // The number of bytes currently allocated. This serves as the "pointer" to the
    // next free byte in the memory.
    private allocatedBytes: number;

    constructor(memory: WebAssembly.Memory, offset: number) {
        this.memory = memory;
        // Initialize the allocator with offset allocated bytes.
        this.allocatedBytes = offset;
    }

    /**
     * Allocates a block of memory of the specified size, returning the pointer to the
     * beginning of the block. The block is allocated at the current offset, aligned on
     * 8 bytes, and the offset is incremented by the size of the block.
     *
     * @param sizeInBytes The size of the block to allocate in bytes.
     * @returns The offset (pointer) to the beginning of the allocated block.
     */
    alloc(sizeInBytes: number): number {
        // Store the current offset as the start of the new block, aligned on 8 bytes:
        // blocks hold double samples and int64 values, accessed with typed arrays views
        // whose index is the byte offset divided by the item size.
        const currentOffset = (this.allocatedBytes + 7) & ~7;
        // Calculate the new offset after allocating the requested block.
        const newOffset = currentOffset + sizeInBytes;
        // Get the total size of the WebAssembly memory in bytes.
        const totalMemoryBytes = this.memory.buffer.byteLength;

        // If the new offset exceeds the total size of the memory, grow the memory.
        if (newOffset > totalMemoryBytes) {
            // Calculate the number of WebAssembly pages needed to fit the new allocation.
            // WebAssembly memory pages are 64KiB each.
            const neededPages = Math.ceil(
                (newOffset - totalMemoryBytes) / 65536
            );
            // Grow the memory by the required number of pages.
            console.log(`GROW: ${neededPages} pages`);
            this.memory.grow(neededPages);
        }

        // Update the allocated bytes to the new offset.
        this.allocatedBytes = newOffset;
        // Return the offset at which the allocated block starts.
        return currentOffset;
    }

    /**
     * Returns the underlying buffer object.
     *
     * @returns The buffer object.
     */
    getBuffer(): ArrayBuffer {
        return this.memory.buffer;
    }

    /**
     * Returns the Int32 view of the underlying buffer object.
     *
     * @returns The view of the memory buffer as Int32Array.
     */
    getInt32Array(): Int32Array {
        return new Int32Array(this.memory.buffer);
    }

    /**
     * Returns the Int64 view of the underlying buffer object.
     *
     * @returns The view of the memory buffer as BigInt64Array.
     */
    getInt64Array(): BigInt64Array {
        return new BigInt64Array(this.memory.buffer);
    }

    /**
     * Returns the Float32 view of the underlying buffer object.
     *
     * @returns The view of the memory buffer as Float32Array.
     */
    getFloat32Array(): Float32Array {
        return new Float32Array(this.memory.buffer);
    }

    /**
     * Returns the Float64 view of the underlying buffer object..
     *
     * @returns The view of the memory buffer as Float64Array.
     */
    getFloat64Array(): Float64Array {
        return new Float64Array(this.memory.buffer);
    }
}

/**
 * Soundfile class to handle soundfile data in wasm memory.
 *
 * The structure is the one of architecture/faust/gui/Soundfile.h, laid out flat:
 * 4 pointers (fBuffers, fLength, fSR, fOffset), then 3 int32 (fChannels, fParts, fIsDouble).
 * The generated code reads channel 'chan' as 'chan % fChannels', so fBuffers only holds
 * the fChannels real channels: a soundfile can be read with more channels than it has.
 */
export class Soundfile {
    /** Maximum number of soundfile parts. */
    static get MAX_SOUNDFILE_PARTS() {
        return 256;
    }

    /**
     * @deprecated channels are no more duplicated up to MAX_CHAN: the generated code
     * reads channel 'chan % fChannels'.
     */
    static get MAX_CHAN() {
        return 64;
    }

    /** Maximum buffer size in frames. */
    static get BUFFER_SIZE() {
        return 1024;
    }

    /** Default sample rate. */
    static get SAMPLE_RATE() {
        return 44100;
    }

    /** Pointer to the soundfile structure in wasm memory */
    private readonly fPtr: number;
    private readonly fBuffers: number;
    private readonly fLength: number;
    private readonly fSR: number;
    private readonly fOffset: number;
    private readonly fSampleSize: number;
    private readonly fPtrSize: number;
    private readonly fIntSize: number;
    private readonly fAllocator: WasmAllocator;

    /**
     * @param _maxChan - deprecated and ignored: only the curChan real channels are allocated
     */
    constructor(
        allocator: WasmAllocator,
        sampleSize: number,
        curChan: number,
        length: number,
        _maxChan: number,
        totalParts: number
    ) {
        this.fSampleSize = sampleSize;

        // To be coherent with the code generated by the wast/wasm backends:
        // - that uses 4 bytes for int when float is used
        // - that uses 8 bytes for int when double is used (to simplify the code generation)
        this.fIntSize = this.fSampleSize;

        this.fPtrSize = 4; // Not related to float/double choice, so always 4

        this.fAllocator = allocator;

        console.log(
            `Soundfile constructor: curChan: ${curChan}, length: ${length}, totalParts: ${totalParts}`
        );

        // Allocate wasm memory for the soundfile structure:
        // fBuffers, fLength, fSR, fOffset pointers, then fChannels, fParts, fIsDouble int32
        this.fPtr = allocator.alloc(4 * this.fPtrSize + 3 * 4);

        // Use the 4 or 8 bytes size for int. The access are then adapted in copyToOut and emptyFile methods
        this.fLength = allocator.alloc(
            Soundfile.MAX_SOUNDFILE_PARTS * this.fIntSize
        );
        this.fSR = allocator.alloc(
            Soundfile.MAX_SOUNDFILE_PARTS * this.fIntSize
        );
        this.fOffset = allocator.alloc(
            Soundfile.MAX_SOUNDFILE_PARTS * this.fIntSize
        );

        this.fBuffers = this.allocBuffers(curChan, length);

        //this.displayMemory("Allocated soundfile structure 1");

        // Set the soundfile structure in wasm memory
        const HEAP32 = this.fAllocator.getInt32Array();
        HEAP32[this.fPtr >> 2] = this.fBuffers;
        HEAP32[(this.fPtr + this.fPtrSize) >> 2] = this.fLength;
        HEAP32[(this.fPtr + 2 * this.fPtrSize) >> 2] = this.fSR;
        HEAP32[(this.fPtr + 3 * this.fPtrSize) >> 2] = this.fOffset;
        // Read by the generated code to wrap the channel index (chan % fChannels): has to be >= 1
        HEAP32[(this.fPtr + 4 * this.fPtrSize) >> 2] = curChan;
        HEAP32[(this.fPtr + 4 * this.fPtrSize + 4) >> 2] = totalParts;
        HEAP32[(this.fPtr + 4 * this.fPtrSize + 8) >> 2] =
            this.fSampleSize === 8 ? 1 : 0;

        for (let chan = 0; chan < curChan; chan++) {
            const buffer: number = HEAP32[(this.fBuffers >> 2) + chan];
            console.log(`allocBuffers AFTER: ${chan} - ${buffer}`);
        }

        //this.displayMemory("Allocated soundfile structure 2");
    }

    private allocBuffers(curChan: number, length: number): number {
        const buffers = this.fAllocator.alloc(curChan * this.fPtrSize);

        console.log(`allocBuffers buffers: ${buffers}`);

        for (let chan = 0; chan < curChan; chan++) {
            const buffer: number = this.fAllocator.alloc(
                length * this.fSampleSize
            );
            // HEAP32 is the Int32Array view of the memory buffer which can change after grow in `alloc` method
            // so we need to recompute the buffer address
            const HEAP32 = this.fAllocator.getInt32Array();
            HEAP32[(buffers >> 2) + chan] = buffer;
        }
        //this.displayMemory("Allocated soundfile buffers");
        return buffers;
    }

    copyToOut(
        part: number,
        maxChannels: number,
        offset: number,
        audioData: AudioData
    ) {
        // Set the soundfile fields in wasm memory
        if (this.fIntSize === 4) {
            const HEAP32 = this.fAllocator.getInt32Array();
            HEAP32[(this.fLength >> Math.log2(this.fIntSize)) + part] =
                audioData.audioBuffer[0].length;
            HEAP32[(this.fSR >> Math.log2(this.fIntSize)) + part] =
                audioData.sampleRate;
            HEAP32[(this.fOffset >> Math.log2(this.fIntSize)) + part] = offset;
        } else {
            const HEAP64 = this.fAllocator.getInt64Array();
            HEAP64[(this.fLength >> Math.log2(this.fIntSize)) + part] = BigInt(
                audioData.audioBuffer[0].length
            );
            HEAP64[(this.fSR >> Math.log2(this.fIntSize)) + part] = BigInt(
                audioData.sampleRate
            );
            HEAP64[(this.fOffset >> Math.log2(this.fIntSize)) + part] =
                BigInt(offset);
        }

        console.log(
            `copyToOut: part: ${part}, maxChannels: ${maxChannels}, offset: ${offset}, buffer: ${audioData}`
        );

        //this.displayMemory("IN copyToOut, BEFORE copyToOutReal", true);
        // Copy the soundfile data to the buffer
        if (this.fSampleSize === 8) {
            this.copyToOutReal64(maxChannels, offset, audioData);
        } else {
            this.copyToOutReal32(maxChannels, offset, audioData);
        }
        //this.displayMemory("IN copyToOut, AFTER copyToOutReal");
    }

    copyToOutReal32(maxChannels: number, offset: number, audioData: AudioData) {
        const HEAP32 = this.fAllocator.getInt32Array();
        const HEAPF = this.fAllocator.getFloat32Array();
        for (let chan = 0; chan < audioData.audioBuffer.length; chan++) {
            const input: Float32Array = audioData.audioBuffer[chan];
            const output: number = HEAP32[(this.fBuffers >> 2) + chan];
            const begin: number =
                (output + offset * this.fSampleSize) >>
                Math.log2(this.fSampleSize);
            const end: number =
                (output + (offset + input.length) * this.fSampleSize) >>
                Math.log2(this.fSampleSize);
            console.log(
                `copyToOutReal32 begin: ${begin}, end: ${end}, delta: ${end - begin}`
            );
            const outputReal: Float32Array = HEAPF.subarray(
                (output + offset * this.fSampleSize) >>
                    Math.log2(this.fSampleSize),
                (output + (offset + input.length) * this.fSampleSize) >>
                    Math.log2(this.fSampleSize)
            );
            for (let sample = 0; sample < input.length; sample++) {
                outputReal[sample] = input[sample];
            }
        }
    }

    copyToOutReal64(maxChannels: number, offset: number, audioData: AudioData) {
        const HEAP32 = this.fAllocator.getInt32Array();
        const HEAPF = this.fAllocator.getFloat64Array();
        for (let chan = 0; chan < audioData.audioBuffer.length; chan++) {
            const input: Float32Array = audioData.audioBuffer[chan];
            const output: number = HEAP32[(this.fBuffers >> 2) + chan];
            const begin: number =
                (output + offset * this.fSampleSize) >>
                Math.log2(this.fSampleSize);
            const end: number =
                (output + (offset + input.length) * this.fSampleSize) >>
                Math.log2(this.fSampleSize);
            console.log(
                `copyToOutReal64 begin: ${begin}, end: ${end}, delta: ${end - begin}`
            );
            const outputReal: Float64Array = HEAPF.subarray(
                (output + offset * this.fSampleSize) >>
                    Math.log2(this.fSampleSize),
                (output + (offset + input.length) * this.fSampleSize) >>
                    Math.log2(this.fSampleSize)
            );
            for (let sample = 0; sample < input.length; sample++) {
                outputReal[sample] = input[sample];
            }
        }
    }

    emptyFile(part: number, offset: number): number {
        // Set the soundfile fields in wasm memory
        if (this.fIntSize === 4) {
            const HEAP32 = this.fAllocator.getInt32Array();
            HEAP32[(this.fLength >> Math.log2(this.fIntSize)) + part] =
                Soundfile.BUFFER_SIZE;
            HEAP32[(this.fSR >> Math.log2(this.fIntSize)) + part] =
                Soundfile.SAMPLE_RATE;
            HEAP32[(this.fOffset >> Math.log2(this.fIntSize)) + part] = offset;
        } else {
            const HEAP64 = this.fAllocator.getInt64Array();
            HEAP64[(this.fLength >> Math.log2(this.fIntSize)) + part] = BigInt(
                Soundfile.BUFFER_SIZE
            );
            HEAP64[(this.fSR >> Math.log2(this.fIntSize)) + part] = BigInt(
                Soundfile.SAMPLE_RATE
            );
            HEAP64[(this.fOffset >> Math.log2(this.fIntSize)) + part] =
                BigInt(offset);
        }

        // Update and return the new offset
        return offset + Soundfile.BUFFER_SIZE;
    }

    displayMemory(where: string = '', mem: boolean = false) {
        console.log('Soundfile memory: ' + where);
        console.log(`fPtr: ${this.fPtr}`);
        console.log(`fBuffers: ${this.fBuffers}`);
        console.log(`fLength: ${this.fLength}`);
        console.log(`fSR: ${this.fSR}`);
        console.log(`fOffset: ${this.fOffset}`);
        const HEAP32 = this.fAllocator.getInt32Array();
        if (mem) console.log(`HEAP32: ${HEAP32}`);
        console.log(`HEAP32[this.fPtr >> 2]: ${HEAP32[this.fPtr >> 2]}`);
        console.log(
            `HEAP32[(this.fPtr + ptrSize) >> 2]: ${HEAP32[(this.fPtr + this.fPtrSize) >> 2]}`
        );
        console.log(
            `HEAP32[(this.fPtr + 2 * ptrSize) >> 2]: ${HEAP32[(this.fPtr + 2 * this.fPtrSize) >> 2]}`
        );
        console.log(
            `HEAP32[(this.fPtr + 3 * ptrSize) >> 2]: ${HEAP32[(this.fPtr + 3 * this.fPtrSize) >> 2]}`
        );
    }

    // Return the pointer to the soundfile structure in wasm memory
    getPtr(): number {
        return this.fPtr;
    }

    getHEAP32(): Int32Array {
        return this.fAllocator.getInt32Array();
    }
    getHEAPFloat32(): Float32Array {
        return this.fAllocator.getFloat32Array();
    }

    getHEAPFloat64(): Float64Array {
        return this.fAllocator.getFloat64Array();
    }
}

/**
 * DSP implementation that mimic the C++ 'dsp' class:
 * - adding MIDI control: metadata are decoded and incoming MIDI messages will control the associated controllers
 * - an output handler can be set to treat produced output controllers (like 'bargraph')
 * - an input handler can be set to follow control parameter changes (like sliders)
 * - regular controllers are handled using setParamValue/getParamValue and getParams methods
 */
export interface IFaustBaseWebAudioDsp {
    /**
     * Set the parameter output handler, to  be called in the 'compute' method with output parameters (like bargraph).
     *
     * @param handler - the output handler
     */
    setOutputParamHandler(handler: OutputParamHandler | null): void;

    /**
     * Get the parameter output handler.
     *
     * @return the current output handler
     */
    getOutputParamHandler(): OutputParamHandler | null;

    /**
     * Call the output parameter handler with a path and value.
     *
     * @param path - the path to the wanted parameter (retrieved using 'getParams' method)
     * @param value - the float value for the wanted control
     */
    callOutputParamHandler(path: string, value: number): void;

    /**
     * Set the parameter input handler, to be called when input parameters change (like sliders).
     *
     * @param handler - the input handler
     */
    setInputParamHandler(handler: InputParamHandler | null): void;

    /**
     * Get the parameter input handler.
     *
     * @return the current input handler
     */
    getInputParamHandler(): InputParamHandler | null;

    /**
     * Call the input parameter handler with a path and value.
     *
     * @param path - the path to the wanted parameter (retrieved using 'getParams' method)
     * @param value - the float value for the wanted control
     */
    callInputParamHandler(path: string, value: number): void;

    /**
     * Set the compute handler, to  be called in the 'compute' method with buffer size.
     *
     * @param handler - the compute handler
     */
    setComputeHandler(handler: ComputeHandler | null): void;

    /**
     * Get the compute handler.
     *
     * @return the current output handler
     */
    getComputeHandler(): ComputeHandler | null;

    /**
     * Set the plot handler, to  be called in the 'compute' method with various info (see PlotHandler type).
     *
     * @param handler - the plot handler
     */
    setPlotHandler(handler: PlotHandler | null): void;

    /**
     * Get the plot handler.
     *
     * @return the current plot handler
     */
    getPlotHandler(): PlotHandler | null;

    /**
     * Set the non-finite handler, and with it the non-finite guard: while a
     * handler is set, 'compute' replaces every NaN or infinite output sample with
     * 0, so nothing after the DSP is poisoned and no full-scale click reaches the
     * output, and the handler is called the first time it happens. Without one,
     * nothing is checked and the output is exactly what the DSP computed -- the
     * guard is opt-in, like 'dsp_me_checker' on the C++ side.
     *
     * The DSP's own state usually stays broken (a filter or a delay line does not
     * recover from a NaN), so the handler is the host's cue to say which DSP it
     * was. It is called once per DSP instance, not once per block; a host that
     * only wants the output cleared can pass a handler that does nothing.
     *
     * @param handler - the non-finite handler, or null to turn the guard off
     */
    setNonFiniteHandler(handler: NonFiniteHandler | null): void;

    /**
     * Get the non-finite handler.
     *
     * @return the current non-finite handler
     */
    getNonFiniteHandler(): NonFiniteHandler | null;

    /**
     * Return instance number of audio inputs.
     *
     * @return the instance number of audio inputs
     */
    getNumInputs(): number;

    /**
     * Return instance number of audio outputs.
     *
     * @return the instance number of audio outputs
     */
    getNumOutputs(): number;

    /**
     * DSP instance computation, to be called with successive input/output audio buffers, using their size.
     *
     * @param inputs - the input audio buffers
     * @param outputs - the output audio buffers
     * @param events - control writes due inside this block, sorted by frame.
     * The block is rendered in slices around them, so each one takes effect on
     * the frame it was timestamped for instead of at the start of the block.
     */
    compute(
        inputs: Float32Array[],
        outputs: Float32Array[],
        events?: FaustTimedEvent[]
    ): boolean;

    /**
     * Give a handler to be called on 'declare key value' kind of metadata.
     *
     * @param handler - the handler to be used
     */
    metadata(handler: MetadataHandler): void;

    /**
     * Handle untyped MIDI messages.
     *
     * Channel voice messages (notes, controllers, program change, pressure,
     * pitch bend) on another channel than the one given to `setMidiChannel`
     * are ignored.
     *
     * @param data - and arry of MIDI bytes
     */
    midiMessage(data: number[] | Uint8Array): void;

    /**
     * Receive only one MIDI channel in `midiMessage`.
     *
     * Real-time and SysEx messages are always received. The typed methods
     * (`keyOn`, `keyOff`, `ctrlChange`, `pitchWheel`) are calls of the host,
     * not MIDI input, and are not filtered: an on-screen keyboard keeps
     * playing whatever channel it sends on.
     *
     * The default is the `declare options "[midichannel:N]";` (or
     * `declare midichannel "N";`) metadata of the DSP, otherwise 0.
     *
     * @param channel - in 1..16, or 0 to receive all channels. Any other
     * value means 0.
     */
    setMidiChannel(channel: number): void;

    /**
     * Return the received MIDI channel, in 1..16, or 0 for all channels.
     */
    getMidiChannel(): number;

    /**
     * Handle MIDI ctrlChange messages.
     *
     * @param channel - the MIDI channel (0..15)
     * @param ctrl - the MIDI controller number (0..127)
     * @param value - the MIDI controller value (0..127)
     */
    ctrlChange(chan: number, ctrl: number, value: number): void;

    /**
     * Handle MIDI pitchWheel messages.
     *
     * @param channel - the MIDI channel (0..15)
     * @param value - the MIDI controller value (0..16383)
     */
    pitchWheel(chan: number, value: number): void;

    /**
     * Handle MIDI keyOn messages.
     * @param channel
     * @param pitch
     * @param velocity
     */
    keyOn(channel: number, pitch: number, velocity: number): void;

    /**
     * Handle MIDI keyOn messages.
     * @param channel
     * @param pitch
     * @param velocity
     */
    keyOff(channel: number, pitch: number, velocity: number): void;

    /**
     * Set parameter value.
     *
     * @param path - the path to the wanted parameter (retrieved using 'getParams' method)
     * @param val - the float value for the wanted control
     */
    setParamValue(path: string, value: number): void;

    /**
     * Get parameter value.
     *
     * @param path - the path to the wanted parameter (retrieved using 'getParams' method)
     *
     * @return the float value
     */
    getParamValue(path: string): number;

    /**
     * Get the table of all input parameters paths.
     *
     * @return the table of all input parameters paths
     */
    getParams(): string[];

    /**
     * Get DSP JSON description with its UI and metadata as object.
     *
     * @return the DSP JSON description as object
     */
    getMeta(): FaustDspMeta;

    /**
     * Get DSP UI description.
     *
     * @return the DSP UI description
     */
    getUI(): FaustUIDescriptor;

    /**
     * Get DSP UI items description.
     *
     * @return the DSP UI items description
     */
    getDescriptors(): FaustUIInputItem[];

    /**
     * Get DSP JSON description with its UI and metadata.
     *
     * @return the DSP JSON description
     */
    getJSON(): string;

    /**
     * Start accelerometer and gyroscope handlers.
     */
    startSensors(): void;

    /**
     * Stop accelerometer and gyroscope handlers.
     */
    stopSensors(): void;

    /** Indicating if the DSP handles the accelerometer */
    readonly hasAccInput: boolean;

    /**
     * Accelerometer handling.
     * accelerationIncludingGravity: DeviceMotionEvent["accelerationIncludingGravity"]
     * invert: boolean
     */
    propagateAcc(
        accelerationIncludingGravity: NonNullable<
            DeviceMotionEvent['accelerationIncludingGravity']
        >,
        invert: boolean
    ): void;

    /** Indicating if the DSP handles the gyroscope */
    readonly hasGyrInput: boolean;

    /**
     * Gyroscope handling.
     * event: Pick<DeviceOrientationEvent, "alpha" | "beta" | "gamma">
     */
    propagateGyr(
        event: Pick<DeviceOrientationEvent, 'alpha' | 'beta' | 'gamma'>
    ): void;

    /**
     * Reinitialize the DSP using its configured sample rate.
     */
    init(): void;

    /**
     * Reinitialize the DSP instance state using its configured sample rate.
     */
    instanceInit(): void;

    /**
     * Clear the DSP instance state.
     */
    instanceClear(): void;

    /**
     * Reinitialize the DSP instance constants using its configured sample rate.
     */
    instanceConstants(): void;

    /**
     * Reset DSP user interface parameters to their default values.
     */
    instanceResetUserInterface(): void;

    /**
     * Start the DSP audio processing.
     */
    start(): void;

    /**
     * Stop the DSP audio processing.
     */
    stop(): void;

    /**
     * Destroy the DSP.
     */
    destroy(): void;
}

export type IFaustMonoWebAudioDsp = IFaustBaseWebAudioDsp;

/**
 * A node's controls, each taking an optional time.
 *
 * `time` is in AudioContext seconds, the same clock as
 * `AudioParam.setValueAtTime`, so notes and parameter automation can be
 * scheduled against each other.
 *
 * It is declared on the node rather than on `IFaustBaseWebAudioDsp` because
 * only a node can honour it: it reaches its DSP over a message port and can
 * hold the write until the right block. A DSP is called from inside the block
 * and has nowhere to put a future event.
 *
 * An AudioWorklet node applies the control on the exact sample. A
 * ScriptProcessor node (`sp: true`) accepts `time` and ignores it.
 */
export interface IFaustMonoWebAudioNode
    extends IFaustMonoWebAudioDsp, AudioNode {
    midiMessage(data: number[] | Uint8Array, time?: number): void;
    ctrlChange(chan: number, ctrl: number, value: number, time?: number): void;
    pitchWheel(chan: number, value: number, time?: number): void;
    setParamValue(path: string, value: number, time?: number): void;
}

export interface IFaustPolyWebAudioDsp extends IFaustBaseWebAudioDsp {
    /**
     * Handle MIDI keyOn messages.
     *
     * @param channel - the MIDI channel (0..15), kept by the voice the note starts
     * @param pitch - the MIDI pitch value (0..127)
     * @param velocity - the MIDI velocity value (0..127)
     */
    keyOn(channel: number, pitch: number, velocity: number): void;

    /**
     * Handle MIDI keyOff messages.
     *
     * @param channel - the MIDI channel (0..15): only a voice started on
     * this channel with this pitch is released
     * @param pitch - the MIDI pitch value (0..127)
     * @param velocity - the MIDI velocity value (0..127)
     */
    keyOff(channel: number, pitch: number, velocity: number): void;

    /**
     * Stop all playing notes.
     *
     * @param hard - whether to immediately stop notes or put them in release mode
     */
    allNotesOff(hard: boolean): void;

    /**
     * Return the number of voices still sounding: playing, in their release or
     * in legato. A released voice counts until it has died away.
     *
     * An AudioWorklet node returns the count the audio thread last reported,
     * at the end of the block in which it changed.
     */
    getNumActiveVoices(): number;
}
/** As `IFaustMonoWebAudioNode`, with the notes timestamped too. */
export interface IFaustPolyWebAudioNode
    extends IFaustPolyWebAudioDsp, AudioNode {
    midiMessage(data: number[] | Uint8Array, time?: number): void;
    ctrlChange(chan: number, ctrl: number, value: number, time?: number): void;
    pitchWheel(chan: number, value: number, time?: number): void;
    setParamValue(path: string, value: number, time?: number): void;
    keyOn(
        channel: number,
        pitch: number,
        velocity: number,
        time?: number
    ): void;
    keyOff(
        channel: number,
        pitch: number,
        velocity: number,
        time?: number
    ): void;
}

export class FaustBaseWebAudioDsp implements IFaustBaseWebAudioDsp {
    protected fOutputHandler: OutputParamHandler | null = null;
    protected fInputHandler: InputParamHandler | null = null;
    protected fComputeHandler: ComputeHandler | null = null;

    // Told once when the DSP first produces a non-finite output sample
    protected fNonFiniteHandler: NonFiniteHandler | null = null;
    protected fNonFiniteReported = false;

    // To handle MIDI events plot
    protected fPlotHandler: PlotHandler | null = null;
    protected fCachedEvents: { type: string; data: any }[] = [];
    protected fBufferNum = 0;

    protected fInChannels: Float32Array[] | Float64Array[] = [];
    protected fOutChannels: Float32Array[] | Float64Array[] = [];

    protected fOutputsTimer = 5;

    // UI items path
    protected fInputsItems: string[] = [];
    protected fOutputsItems: string[] = [];
    protected fDescriptor: FaustUIInputItem[] = [];

    // Soundfile handling
    protected fSoundfiles: SoundfileItem[] = [];
    protected fSoundfileBuffers: LooseFaustDspFactory['soundfiles'] = {};
    /** Keep the end of memory offset before soundfiles */
    protected fEndMemory: number;

    // Accelerometer handling
    protected fAcc: SensorEventHandlers; // array of accelerometer handlers on x,y,y axes, to be called with DeviceMotionEvent
    protected fGyr: SensorEventHandlers; // array of gyroscope handlers on alpha,beta,gama axes, to be called with DeviceMotionEvent

    // Buffers in wasm memory
    protected fAudioInputs!: number;
    protected fAudioOutputs!: number;

    /**
     * Block-start address of every wasm audio channel, plus the heap view
     * holding the pointer tables.
     *
     * Rendering a slice means giving wasm a channel pointer to the slice's
     * first frame, so `setBufferOffset` rewrites the tables and needs these
     * unmoved addresses to offset from. Only the tables move; the
     * `fInChannels` / `fOutChannels` views from `initMemory` still span the
     * whole block and stay valid.
     */
    protected fInBase: number[] = [];
    protected fOutBase: number[] = [];
    protected fHEAP32!: Int32Array;

    protected fBufferSize: number;
    protected fPtrSize: number;
    protected fSampleSize: number;

    // MIDI handling
    protected fPitchwheelLabel: {
        path: string;
        chan: number;
        min: number;
        max: number;
    }[] = [];
    protected fCtrlLabel: {
        path: string;
        chan: number;
        min: number;
        max: number;
    }[][] = new Array(128).fill(null).map(() => []);
    // array of MIDI key handlers; array index is the MIDI note number
    protected fMidiKeyLabel: {
        path: string;
        chan: number;
        min: number;
        max: number;
    }[][] = new Array(128).fill(null).map(() => []);
    protected fMidiKeyOnLabel: {
        path: string;
        chan: number;
        min: number;
        max: number;
    }[][] = new Array(128).fill(null).map(() => []);
    protected fMidiKeyOffLabel: {
        path: string;
        chan: number;
        min: number;
        max: number;
    }[][] = new Array(128).fill(null).map(() => []);

    // Received MIDI channel in 1..16, 0 for all channels (see setMidiChannel)
    protected fMidiChannel = 0;

    protected fPathTable: { [address: string]: number } = {};

    /** Paths already complained about, so the warning is not repeated. */
    protected fUnknownPaths: Set<string> = new Set();

    /**
     * Report a parameter path that is in no control's alias list.
     *
     * Silence here is expensive: the path is a typo, or one kept from an
     * older version of the DSP, and without a word the control simply does
     * nothing while the caller believes it worked. But this can be reached
     * from the audio thread, at the rate a host moves a slider, so each path
     * is reported once and then let through quietly.
     *
     * @param path - the path that was not found
     * @param action - what was done instead
     */
    protected warnUnknownPath(path: string, action: string) {
        if (this.fUnknownPaths.has(path)) return;
        this.fUnknownPaths.add(path);
        console.warn(
            `Faust: unknown parameter path "${path}", ${action}. ` +
                `Use getParams() for the list of valid paths.`
        );
    }
    protected fUICallback: UIHandler = (item: FaustUIItem) => {
        if (item.type === 'hbargraph' || item.type === 'vbargraph') {
            const registerPath = (alias: string) => {
                if (this.fPathTable[alias] === undefined) {
                    this.fPathTable[alias] = item.index;
                }
            };
            // Keep bargraph adresses
            this.fOutputsItems.push(item.address);
            registerPath(item.address);
            registerPath(item.shortname);
            registerPath(item.label);
        } else if (
            item.type === 'vslider' ||
            item.type === 'hslider' ||
            item.type === 'button' ||
            item.type === 'checkbox' ||
            item.type === 'nentry'
        ) {
            const registerPath = (alias: string) => {
                if (this.fPathTable[alias] === undefined) {
                    this.fPathTable[alias] = item.index;
                }
            };
            // Keep inputs adresses
            this.fInputsItems.push(item.address);
            registerPath(item.address);
            registerPath(item.shortname);
            registerPath(item.label);
            this.fDescriptor.push(item);
            if (!item.meta) return;
            item.meta.forEach((meta) => {
                const { midi, acc, gyr } = meta;
                // Parse 'midi' metadata
                if (midi) {
                    const strMidi = midi.trim();
                    if (strMidi === 'pitchwheel') {
                        const matched = strMidi.match(/^pitchwheel\s(\d+)/);
                        // "pitchwheel chan"
                        if (matched) {
                            this.fPitchwheelLabel.push({
                                path: item.address,
                                chan: parseInt(matched[1]),
                                min: item.min as number,
                                max: item.max as number
                            });
                            // "pitchwheel"
                        } else {
                            this.fPitchwheelLabel.push({
                                path: item.address,
                                chan: 0,
                                min: item.min as number,
                                max: item.max as number
                            });
                        }
                    } else {
                        // "ctrl num chan"
                        const matched2 = strMidi.match(/^ctrl\s(\d+)\s(\d+)/);
                        // "ctrl num"
                        const matched1 = strMidi.match(/^ctrl\s(\d+)/);
                        // match `key <note>[ <channel>]`
                        const matchedKey = strMidi.match(
                            /^key\s+(\d+)(?:\s+(\d+))?$/
                        );
                        //match `keyon <note>[ <channel>]`
                        const matchedKeyOn = strMidi.match(
                            /^keyon\s+(\d+)(?:\s+(\d+))?$/
                        );
                        //match `keyoff <note>[ <channel>]`
                        const matchedKeyOff = strMidi.match(
                            /^keyoff\s+(\d+)(?:\s+(\d+))?$/
                        );
                        if (matched2) {
                            this.fCtrlLabel[parseInt(matched2[1])].push({
                                path: item.address,
                                chan: parseInt(matched2[2]),
                                min: item.min as number,
                                max: item.max as number
                            });
                        } else if (matched1) {
                            this.fCtrlLabel[parseInt(matched1[1])].push({
                                path: item.address,
                                chan: 0,
                                min: item.min as number,
                                max: item.max as number
                            });
                        } else if (matchedKey) {
                            const note = parseInt(matchedKey[1]);
                            const channel = matchedKey[2]
                                ? parseInt(matchedKey[2])
                                : 0;
                            this.fMidiKeyLabel[note].push({
                                path: item.address,
                                chan: channel,
                                min: (item.min as number) ?? 0,
                                max: (item.max as number) ?? 1
                            });
                        } else if (matchedKeyOn) {
                            const note = parseInt(matchedKeyOn[1]);
                            const channel = matchedKeyOn[2]
                                ? parseInt(matchedKeyOn[2])
                                : 0;
                            this.fMidiKeyOnLabel[note].push({
                                path: item.address,
                                chan: channel,
                                min: (item.min as number) ?? 0,
                                max: (item.max as number) ?? 1
                            });
                        } else if (matchedKeyOff) {
                            const note = parseInt(matchedKeyOff[1]);
                            const channel = matchedKeyOff[2]
                                ? parseInt(matchedKeyOff[2])
                                : 0;
                            this.fMidiKeyOffLabel[note].push({
                                path: item.address,
                                chan: channel,
                                min: (item.min as number) ?? 0,
                                max: (item.max as number) ?? 1
                            });
                        }
                    }
                }

                // Parse 'acc' metadata
                if (acc) {
                    const numAcc: number[] = acc.trim().split(' ').map(Number);
                    this.setupAccHandler(
                        item.address,
                        FaustSensors.convertToAxis(numAcc[0]),
                        FaustSensors.convertToCurve(numAcc[1]),
                        numAcc[2],
                        numAcc[3],
                        numAcc[4],
                        item.min as number,
                        item.init as number,
                        item.max as number
                    );
                }
                // Parse 'gyr' metadata
                if (gyr) {
                    const numAcc: number[] = gyr.trim().split(' ').map(Number);
                    this.setupGyrHandler(
                        item.address,
                        FaustSensors.convertToAxis(numAcc[0]),
                        FaustSensors.convertToCurve(numAcc[1]),
                        numAcc[2],
                        numAcc[3],
                        numAcc[4],
                        item.min as number,
                        item.init as number,
                        item.max as number
                    );
                }
            });
        } else if (item.type === 'soundfile') {
            this.fSoundfiles.push({
                name: item.label,
                url: item.url,
                index: item.index,
                basePtr: -1
            });
        }
    };

    // Audio callback
    protected fProcessing = false;
    protected fDestroyed = false;
    protected fFirstCall = true;

    protected fJSONDsp!: FaustDspMeta;

    constructor(
        sampleSize: number,
        bufferSize: number,
        soundfiles: LooseFaustDspFactory['soundfiles']
    ) {
        this.fBufferSize = bufferSize;
        this.fPtrSize = sampleSize; // Done on wast/wasm backend side
        this.fSampleSize = sampleSize;
        this.fSoundfileBuffers = soundfiles;
        this.fAcc = { x: [], y: [], z: [] };
        this.fGyr = { x: [], y: [], z: [] };
    }

    /**
     * Render a whole block through `render`, stopping at each event.
     *
     * Render up to the next event's frame, apply it, continue. Living in the
     * base class means mono and poly only have to supply what rendering a
     * slice means.
     *
     * With no events the block is one slice, which is what every caller that
     * passes no events gets.
     */
    protected renderBlock(
        events: FaustTimedEvent[] | undefined,
        render: (offset: number, count: number) => void
    ) {
        if (!events || events.length === 0) {
            render(0, this.fBufferSize);
            return;
        }
        let frame = 0;
        for (let i = 0; i < events.length; i++) {
            const event = events[i];
            // Clamped, not trusted: a frame past the end of the block would
            // give wasm a count that runs off the end of the channel.
            const at = Math.min(Math.max(event.frame, 0), this.fBufferSize);
            // Two events on one frame leave an empty slice between them,
            // which is not worth a wasm call.
            if (at > frame) {
                render(frame, at - frame);
                frame = at;
            }
            event.apply();
        }
        if (frame < this.fBufferSize) {
            render(frame, this.fBufferSize - frame);
        }
    }

    /**
     * Apply every event without rendering.
     *
     * For the blocks `compute` returns early from: stopped, or an input or
     * output not connected yet. The events have already left the processor's
     * queue, so dropping them here loses them permanently -- a `keyOn` that
     * never sounds, or a parameter the DSP and the host disagree about from
     * then on.
     *
     * A destroyed DSP is the exception, and does drop them.
     */
    protected applyEvents(events?: FaustTimedEvent[]) {
        if (!events) return;
        for (let i = 0; i < events.length; i++) events[i].apply();
    }

    /**
     * Point the wasm channel tables at frame `offset` of the block.
     *
     * Each slice sets this before rendering, so nothing outside `compute`
     * depends on where the previous slice left the tables.
     */
    protected setBufferOffset(offset: number) {
        const bytes = offset * this.fSampleSize;
        for (let chan = 0; chan < this.fInBase.length; chan++) {
            this.fHEAP32[(this.fAudioInputs >> 2) + chan] =
                this.fInBase[chan] + bytes;
        }
        for (let chan = 0; chan < this.fOutBase.length; chan++) {
            this.fHEAP32[(this.fAudioOutputs >> 2) + chan] =
                this.fOutBase[chan] + bytes;
        }
    }

    // Tools
    static remap(
        v: number,
        mn0: number,
        mx0: number,
        mn1: number,
        mx1: number
    ) {
        return ((v - mn0) / (mx0 - mn0)) * (mx1 - mn1) + mn1;
    }

    // JSON parsing functions
    static parseUI(
        ui: FaustUIDescriptor,
        callback: (item: FaustUIItem) => void
    ) {
        ui.forEach((group) => this.parseGroup(group, callback));
    }

    static parseGroup(
        group: FaustUIGroup,
        callback: (item: FaustUIItem) => void
    ) {
        if (group.items) {
            this.parseItems(group.items, callback);
        }
    }
    static parseItems(
        items: FaustUIItem[],
        callback: (item: FaustUIItem) => void
    ) {
        items.forEach((item) => this.parseItem(item, callback));
    }

    static parseItem(item: FaustUIItem, callback: (item: FaustUIItem) => void) {
        if (
            item.type === 'vgroup' ||
            item.type === 'hgroup' ||
            item.type === 'tgroup'
        ) {
            this.parseItems(item.items, callback);
        } else {
            callback(item);
        }
    }

    /** Split the soundfile names and return an array of names */
    static splitSoundfileNames(input: string): string[] {
        // Trim off the curly braces at the start and end, if present
        const trimmed = input.replace(/^\{|\}$/g, '');
        // Split the string into an array of strings and remove first and last characters
        return trimmed
            .split(';')
            .map((str) =>
                str.length <= 2 ? '' : str.substring(1, str.length - 1)
            )
            .map((str) => str.trim())
            .filter((str) => str.length > 0);
    }

    get hasAccInput() {
        return this.fAcc.x.length + this.fAcc.y.length + this.fAcc.z.length > 0;
    }
    propagateAcc(
        accelerationIncludingGravity: NonNullable<
            DeviceMotionEvent['accelerationIncludingGravity']
        >,
        invert: boolean = false
    ) {
        // Get accelerometervalues
        const { x, y, z } = accelerationIncludingGravity;

        if (invert) {
            // Call the accelerometer handlers
            if (x !== null) this.fAcc.x.forEach((handler) => handler(-x));
            if (y !== null) this.fAcc.y.forEach((handler) => handler(-y));
            if (z !== null) this.fAcc.z.forEach((handler) => handler(-z));
        } else {
            // Call the accelerometer handlers
            if (x !== null) this.fAcc.x.forEach((handler) => handler(x));
            if (y !== null) this.fAcc.y.forEach((handler) => handler(y));
            if (z !== null) this.fAcc.z.forEach((handler) => handler(z));
        }
    }

    get hasGyrInput() {
        return this.fGyr.x.length + this.fGyr.y.length + this.fGyr.z.length > 0;
    }
    propagateGyr(
        event: Pick<DeviceOrientationEvent, 'alpha' | 'beta' | 'gamma'>
    ) {
        // Get gyroscope values
        const { alpha, beta, gamma } = event;

        // Call the gyroscope handlers
        if (alpha !== null) this.fGyr.x.forEach((handler) => handler(alpha));
        if (beta !== null) this.fGyr.y.forEach((handler) => handler(beta));
        if (gamma !== null) this.fGyr.z.forEach((handler) => handler(gamma));
    }

    /** Build the accelerometer handler */
    private setupAccHandler(
        path: string,
        axis: Axis,
        curve: Curve,
        amin: number,
        amid: number,
        amax: number,
        min: number,
        init: number,
        max: number
    ) {
        const handler: UpdatableValueConverter = FaustSensors.buildHandler(
            curve,
            amin,
            amid,
            amax,
            min,
            init,
            max
        );
        switch (axis) {
            case Axis.x:
                this.fAcc.x.push((val) =>
                    this.setParamValue(path, handler.uiToFaust(val))
                );
                break;
            case Axis.y:
                this.fAcc.y.push((val) =>
                    this.setParamValue(path, handler.uiToFaust(val))
                );
                break;
            case Axis.z:
                this.fAcc.z.push((val) =>
                    this.setParamValue(path, handler.uiToFaust(val))
                );
                break;
        }
    }

    /** Build the gyroscope handler */
    private setupGyrHandler(
        path: string,
        axis: Axis,
        curve: Curve,
        amin: number,
        amid: number,
        amax: number,
        min: number,
        init: number,
        max: number
    ) {
        const handler: UpdatableValueConverter = FaustSensors.buildHandler(
            curve,
            amin,
            amid,
            amax,
            min,
            init,
            max
        );
        switch (axis) {
            case Axis.x:
                this.fGyr.x.push((val) =>
                    this.setParamValue(path, handler.uiToFaust(val))
                );
                break;
            case Axis.y:
                this.fGyr.y.push((val) =>
                    this.setParamValue(path, handler.uiToFaust(val))
                );
                break;
            case Axis.z:
                this.fGyr.z.push((val) =>
                    this.setParamValue(path, handler.uiToFaust(val))
                );
                break;
        }
    }

    static extractUrlsFromMeta(dspMeta: FaustDspMeta): string[] {
        // Find the entry with the "soundfiles" key
        const soundfilesEntry = dspMeta.meta.find(
            (entry) => entry.soundfiles !== undefined
        );
        // If the entry is found, split the string by semicolon to get the URLs
        if (soundfilesEntry) {
            return soundfilesEntry.soundfiles
                .split(';')
                .filter((url) => url !== '');
        } else {
            return [];
        }
    }

    /**
     * Load a soundfile possibly containing several parts in the DSP struct.
     * Soundfile pointers are located at 'index' offset, to be read in the JSON file.
     * The DSP struct is located at baseDSP in the wasm memory,
     * either a monophonic DSP, or a voice in a polyphonic context.
     *
     * @param allocator : the wasm memory allocator
     * @param baseDSP : the base DSP in the wasm memory
     * @param name : the name of the soundfile
     * @param url : the url of the soundfile
     */
    private loadSoundfile(
        allocator: WasmAllocator,
        baseDSP: number,
        name: string,
        url: string
    ) {
        console.log(`Soundfile ${name} paths: ${url}`);
        const soundfileIds = FaustBaseWebAudioDsp.splitSoundfileNames(url);
        const item = this.fSoundfiles.find((item) => item.url === url);
        if (!item) throw new Error(`Soundfile with ${url} cannot be found !}`);
        // Use the cached Soundfile
        if (item.basePtr !== -1) {
            // Update HEAP32 after soundfile creation
            const HEAP32 = allocator.getInt32Array();
            // Fill the soundfile structure in wasm memory, soundfiles are at the beginning of the DSP memory
            console.log(
                `Soundfile CACHE ${url}} : ${name} loaded at ${item.basePtr} in wasm memory with index ${item.index}`
            );
            // Soundfile is located at 'index' in the DSP struct, to be added with baseDSP in the wasm memory
            HEAP32[(baseDSP + item.index) >> 2] = item.basePtr;
        } else {
            // Create the soundfiles
            const soundfile = this.createSoundfile(
                allocator,
                soundfileIds,
                this.fSoundfileBuffers
            );
            if (soundfile) {
                // Update HEAP32 after soundfile creation
                const HEAP32 = soundfile.getHEAP32();
                // Get the soundfile pointer in wasm memory
                item.basePtr = soundfile.getPtr();
                console.log(
                    `Soundfile ${name} loaded at ${item.basePtr} in wasm memory with index ${item.index}`
                );
                // Soundfile is located at 'index' in the DSP struct, to be added with baseDSP in the wasm memory
                HEAP32[(baseDSP + item.index) >> 2] = item.basePtr;
            } else {
                console.log(
                    `Soundfile ${name} for ${url} cannot be created !}`
                );
            }
        }
    }

    /**
     * Create a soundfile holding the max number of channels of all its parts.
     *
     * @param _maxChan - deprecated and ignored
     */
    createSoundfile(
        allocator: WasmAllocator,
        soundfileIdList: string[],
        soundfiles: LooseFaustDspFactory['soundfiles'],
        _maxChan?: number
    ) {
        let curChan = 1; // At least one channel
        let totalLength = 0;

        // Compute total length and channels max of all files
        for (const soundfileId of soundfileIdList) {
            let chan = 0;
            let len = 0;
            const audioData = soundfiles?.[soundfileId];
            if (audioData) {
                chan = audioData.audioBuffer.length;
                len = audioData.audioBuffer[0].length;
            } else {
                len = Soundfile.BUFFER_SIZE;
                chan = 1;
            }
            curChan = Math.max(curChan, chan);
            totalLength += len;
        }

        // Complete with empty parts
        totalLength +=
            (Soundfile.MAX_SOUNDFILE_PARTS - soundfileIdList.length) *
            Soundfile.BUFFER_SIZE;

        // Create the soundfile
        const soundfile = new Soundfile(
            allocator,
            this.fSampleSize,
            curChan,
            totalLength,
            curChan,
            soundfileIdList.length
        );

        //soundfile.displayMemory("After soundfile creation");
        // Init offset
        let offset = 0;

        // Read all files
        for (let part = 0; part < soundfileIdList.length; part++) {
            const soundfileId = soundfileIdList[part];
            const audioData = soundfiles?.[soundfileId];
            if (audioData) {
                //soundfile.displayMemory("BEFORE copyToOut");
                soundfile.copyToOut(part, curChan, offset, audioData);
                //soundfile.displayMemory("AFTER copyToOut");
                offset += audioData.audioBuffer[0].length;
            } else {
                // Empty sound
                offset = soundfile.emptyFile(part, offset);
            }
        }

        //soundfile.displayMemory("After reading soundfiles");

        // Complete with empty parts
        for (
            let part = soundfileIdList.length;
            part < Soundfile.MAX_SOUNDFILE_PARTS;
            part++
        ) {
            offset = soundfile.emptyFile(part, offset);
        }

        //soundfile.displayMemory("After emptyFile");

        return soundfile;
    }
    /**
     * Init soundfiles memory.
     *
     * @param allocator : the wasm memory allocator
     * @param baseDSP : the DSP struct (either a monophonic DSP of polyphonic voice) base DSP in the wasm memory
     */
    protected initSoundfileMemory(allocator: WasmAllocator, baseDSP: number) {
        // Create and fill the soundfile structure
        for (const { name, url } of this.fSoundfiles) {
            this.loadSoundfile(allocator, baseDSP, name, url);
        }
    }

    protected updateOutputs() {
        if (
            this.fOutputsItems.length > 0 &&
            this.fOutputHandler &&
            this.fOutputsTimer-- === 0
        ) {
            this.fOutputsTimer = 5;
            this.fOutputsItems.forEach((item) =>
                this.fOutputHandler?.(item, this.getParamValue(item))
            );
        }
    }

    // Public API
    metadata(handler: MetadataHandler) {
        if (this.fJSONDsp.meta) {
            this.fJSONDsp.meta.forEach((meta) =>
                handler(Object.keys(meta)[0], meta[Object.keys(meta)[0]])
            );
        }
    }

    compute(input: Float32Array[], output: Float32Array[]) {
        return false;
    }

    setOutputParamHandler(handler: OutputParamHandler | null) {
        this.fOutputHandler = handler;
    }
    getOutputParamHandler() {
        return this.fOutputHandler;
    }
    callOutputParamHandler(path: string, value: number) {
        if (this.fOutputHandler) {
            this.fOutputHandler(path, value);
        }
    }

    setInputParamHandler(handler: InputParamHandler | null) {
        this.fInputHandler = handler;
    }
    getInputParamHandler() {
        return this.fInputHandler;
    }
    callInputParamHandler(path: string, value: number) {
        if (this.fInputHandler) {
            this.fInputHandler(path, value);
        }
    }

    setComputeHandler(handler: ComputeHandler | null) {
        this.fComputeHandler = handler;
    }
    getComputeHandler() {
        return this.fComputeHandler;
    }

    setPlotHandler(handler: PlotHandler | null) {
        this.fPlotHandler = handler;
    }
    getPlotHandler() {
        return this.fPlotHandler;
    }

    setNonFiniteHandler(handler: NonFiniteHandler | null) {
        this.fNonFiniteHandler = handler;
    }
    getNonFiniteHandler() {
        return this.fNonFiniteHandler;
    }

    /**
     * With a non-finite handler set, replace every non-finite sample of the block
     * just computed with 0, and report the first one to the handler.
     *
     * A control the compiler cannot know -- a Q, a divisor -- can make Faust code
     * divide by zero. The NaN stays in the DSP's recursive state for good, and
     * handed on it would poison every stateful node after this one for good too.
     * Called on the DSP's own output channels, before they are copied or handed
     * to an output callback, so every path out of 'compute' is covered.
     */
    protected clearNonFinite() {
        // Opt-in: without a handler the output is left exactly as computed
        if (!this.fNonFiniteHandler) return;
        let found = false;
        const outputs = this.getNumOutputs();
        for (let chan = 0; chan < outputs; chan++) {
            const dspOutput = this.fOutChannels[chan];
            // Fast path, one add per sample: the sum of a block is finite when
            // every sample is. (A sum that overflowed only costs the slow pass
            // below, which then finds nothing.) x - x is 0 for a finite x, and
            // NaN for NaN and for either infinity.
            let sum = 0;
            for (let frame = 0; frame < dspOutput.length; frame++) {
                sum += dspOutput[frame];
            }
            if (sum - sum === 0) continue;
            for (let frame = 0; frame < dspOutput.length; frame++) {
                const sample = dspOutput[frame];
                if (sample - sample !== 0) {
                    dspOutput[frame] = 0;
                    found = true;
                }
            }
        }
        if (found && !this.fNonFiniteReported) {
            this.fNonFiniteReported = true;
            this.fNonFiniteHandler();
        }
    }

    getNumInputs() {
        return -1;
    }
    getNumOutputs() {
        return -1;
    }

    /**
     * Read the received MIDI channel from the DSP metadata:
     * `declare options "[midichannel:N]";` or `declare midichannel "N";`.
     *
     * Same rules as `MidiMeta::getChannel` in the C++ architecture files: an
     * invalid value is reported and means all channels.
     *
     * @param meta - the `meta` array of the DSP JSON
     * @returns the channel in 1..16, or 0 for all channels
     */
    static parseMidiChannel(meta: FaustDspMeta['meta'] | undefined) {
        if (!meta) return 0;
        let value: string | undefined;
        let source = '';
        for (const item of meta) {
            if (typeof item.options === 'string') {
                const match = item.options.match(/\[midichannel:([^\]]*)\]/);
                if (match) {
                    value = match[1];
                    source = '[midichannel] option';
                }
            }
        }
        if (value === undefined) {
            for (const item of meta) {
                if (typeof item.midichannel === 'string') {
                    value = item.midichannel;
                    source = 'midichannel metadata';
                }
            }
        }
        if (value === undefined || value.trim() === '') return 0;
        const channel = /^\s*\d+\s*$/.test(value) ? Number(value) : NaN;
        if (!(channel >= 0 && channel <= 16)) {
            console.warn(
                `Faust: invalid MIDI channel '${value}' in ${source}: should be in 1..16, or 0 for all channels`
            );
            return 0;
        }
        return channel;
    }

    setMidiChannel(channel: number) {
        this.fMidiChannel =
            Number.isInteger(channel) && channel >= 0 && channel <= 16
                ? channel
                : 0;
    }

    getMidiChannel() {
        return this.fMidiChannel;
    }

    /**
     * Whether `midiMessage` receives the channel voice message whose status
     * byte is `status`. Real-time and SysEx messages (0xF0..0xFF) always are.
     */
    protected acceptMidiStatus(status: number) {
        return (
            this.fMidiChannel === 0 ||
            status >= 0xf0 ||
            (status & 0xf) === this.fMidiChannel - 1
        );
    }

    midiMessage(data: number[] | Uint8Array) {
        if (!this.acceptMidiStatus(data[0])) return;
        if (this.fPlotHandler) this.fCachedEvents.push({ data, type: 'midi' });
        const cmd = data[0] >> 4;
        const channel = data[0] & 0xf;
        const data1 = data[1];
        const data2 = data[2];
        if (cmd === 11) return this.ctrlChange(channel, data1, data2);
        if (cmd === 14) return this.pitchWheel(channel, data2 * 128.0 + data1);
        if (cmd === 9) {
            if (data2 > 0) return this.keyOn(channel, data1, data2);
            else return this.keyOff(channel, data1, data2);
        }
        if (cmd === 8) {
            return this.keyOff(channel, data1, data2);
        }
    }

    ctrlChange(channel: number, ctrl: number, value: number) {
        if (this.fPlotHandler)
            this.fCachedEvents.push({
                type: 'ctrlChange',
                data: [channel, ctrl, value]
            });
        if (this.fCtrlLabel[ctrl].length) {
            this.fCtrlLabel[ctrl].forEach((ctrl) => {
                const { path, chan } = ctrl;
                if (chan === 0 || channel === chan - 1) {
                    this.setParamValue(
                        path,
                        FaustBaseWebAudioDsp.remap(
                            value,
                            0,
                            127,
                            ctrl.min,
                            ctrl.max
                        )
                    );
                    // Typically used to reflect parameter change on GUI
                    if (this.fOutputHandler)
                        this.fOutputHandler(path, this.getParamValue(path));
                }
            });
        }
    }

    keyOn(channel: number, pitch: number, velocity: number) {
        if (this.fPlotHandler)
            this.fCachedEvents.push({
                type: 'keyOn',
                data: [channel, pitch, velocity]
            });
        this.fMidiKeyOnLabel[pitch].forEach((key) => {
            const { path, chan } = key;
            if (chan === 0 || channel === chan - 1) {
                this.setParamValue(
                    path,
                    FaustBaseWebAudioDsp.remap(
                        velocity,
                        0,
                        127,
                        key.min,
                        key.max
                    )
                );
                // Typically used to reflect parameter change on GUI
                if (this.fOutputHandler)
                    this.fOutputHandler(path, this.getParamValue(path));
            }
        });
        this.fMidiKeyLabel[pitch].forEach((key) => {
            const { path, chan } = key;
            if (chan === 0 || channel === chan - 1) {
                this.setParamValue(
                    path,
                    FaustBaseWebAudioDsp.remap(
                        velocity,
                        0,
                        127,
                        key.min,
                        key.max
                    )
                );
                // Typically used to reflect parameter change on GUI
                if (this.fOutputHandler)
                    this.fOutputHandler(path, this.getParamValue(path));
            }
        });
    }

    keyOff(channel: number, pitch: number, velocity: number) {
        if (this.fPlotHandler)
            this.fCachedEvents.push({
                type: 'keyOff',
                data: [channel, pitch, velocity]
            });
        this.fMidiKeyOffLabel[pitch].forEach((key) => {
            const { path, chan } = key;
            if (chan === 0 || channel === chan - 1) {
                this.setParamValue(
                    path,
                    FaustBaseWebAudioDsp.remap(
                        velocity,
                        0,
                        127,
                        key.min,
                        key.max
                    )
                );
                // Typically used to reflect parameter change on GUI
                if (this.fOutputHandler)
                    this.fOutputHandler(path, this.getParamValue(path));
            }
        });
        this.fMidiKeyLabel[pitch].forEach((key) => {
            const { path, chan } = key;
            if (chan === 0 || channel === chan - 1) {
                this.setParamValue(path, 0);
                // Typically used to reflect parameter change on GUI
                if (this.fOutputHandler)
                    this.fOutputHandler(path, this.getParamValue(path));
            }
        });
    }

    pitchWheel(channel: number, wheel: number) {
        if (this.fPlotHandler)
            this.fCachedEvents.push({
                type: 'pitchWheel',
                data: [channel, wheel]
            });
        this.fPitchwheelLabel.forEach((pw) => {
            const { path, chan } = pw;
            if (chan === 0 || channel === chan - 1) {
                this.setParamValue(
                    path,
                    FaustBaseWebAudioDsp.remap(wheel, 0, 16383, pw.min, pw.max)
                );
                // Typically used to reflect parameter change on GUI
                if (this.fOutputHandler)
                    this.fOutputHandler(path, this.getParamValue(path));
            }
        });
    }

    setParamValue(path: string, value: number) {}
    getParamValue(path: string) {
        return 0;
    }

    getParams() {
        return this.fInputsItems;
    }
    getMeta() {
        return this.fJSONDsp;
    }
    getJSON() {
        return JSON.stringify(this.getMeta());
    }
    getUI() {
        return this.fJSONDsp.ui;
    }
    getDescriptors() {
        return this.fDescriptor;
    }

    hasSoundfiles() {
        return this.fSoundfiles.length > 0;
    }

    startSensors(): void {
        this.startSensors();
    }

    stopSensors(): void {
        this.stopSensors();
    }

    init() {}

    instanceInit() {}

    instanceClear() {}

    instanceConstants() {}

    instanceResetUserInterface() {}

    start() {
        this.fProcessing = true;
    }

    stop() {
        this.fProcessing = false;
    }

    destroy() {
        this.fDestroyed = true;
        this.fOutputHandler = null;
        this.fInputHandler = null;
        this.fComputeHandler = null;
        this.fPlotHandler = null;
    }
}

export class FaustMonoWebAudioDsp
    extends FaustBaseWebAudioDsp
    implements IFaustMonoWebAudioDsp
{
    private fInstance: FaustMonoDspInstance;
    private fDSP!: number;
    private fSampleRate: number;

    /**
     * Render one slice, for `renderBlock`.
     *
     * A field rather than an inline closure so it is allocated once instead of
     * on every `compute` call.
     */
    private fRenderSlice = (offset: number, count: number) => {
        this.setBufferOffset(offset);
        this.fInstance.api.compute(
            this.fDSP,
            count,
            this.fAudioInputs,
            this.fAudioOutputs
        );
    };

    constructor(
        instance: FaustMonoDspInstance,
        sampleRate: number,
        sampleSize: number,
        bufferSize: number,
        soundfiles: LooseFaustDspFactory['soundfiles']
    ) {
        super(sampleSize, bufferSize, soundfiles);
        this.fInstance = instance;
        this.fSampleRate = sampleRate;

        // Create JSON object
        this.fJSONDsp = JSON.parse(this.fInstance.json);
        this.fMidiChannel = FaustBaseWebAudioDsp.parseMidiChannel(
            this.fJSONDsp.meta
        );

        // Setup GUI
        FaustBaseWebAudioDsp.parseUI(this.fJSONDsp.ui, this.fUICallback);

        // Setup wasm memory
        this.fEndMemory = this.initMemory();

        // Init DSP
        this.fInstance.api.init(this.fDSP, sampleRate);

        // Init soundfiles memory is needed
        if (this.fSoundfiles.length > 0) {
            // Create memory allocator for soundfiles in wasm memory, starting at the end of DSP memory
            const allocator = new WasmAllocator(
                this.fInstance.memory,
                this.fEndMemory
            );

            // Init soundfiles memory
            this.initSoundfileMemory(allocator, this.fDSP);
        }
    }

    init() {
        this.fInstance.api.init(this.fDSP, this.fSampleRate);
    }

    instanceInit() {
        this.fInstance.api.instanceInit(this.fDSP, this.fSampleRate);
    }

    instanceClear() {
        this.fInstance.api.instanceClear(this.fDSP);
    }

    instanceConstants() {
        this.fInstance.api.instanceConstants(this.fDSP, this.fSampleRate);
    }

    instanceResetUserInterface() {
        this.fInstance.api.instanceResetUserInterface(this.fDSP);
    }

    private initMemory(): number {
        // Start of DSP memory: Mono DSP is placed first with index 0
        this.fDSP = 0;

        // Audio buffer start at the end of DSP
        const $audio = this.fJSONDsp.size;

        // Setup audio pointers offset
        this.fAudioInputs = $audio;
        this.fAudioOutputs =
            this.fAudioInputs + this.getNumInputs() * this.fPtrSize;

        // Prepare wasm memory layout
        const $audioInputs =
            this.fAudioOutputs + this.getNumOutputs() * this.fPtrSize;
        const $audioOutputs =
            $audioInputs +
            this.getNumInputs() * this.fBufferSize * this.fSampleSize;
        // Compute memory end in bytes
        const endMemory =
            $audioOutputs +
            this.getNumOutputs() * this.fBufferSize * this.fSampleSize;

        // Setup Int32 and Real views of the memory
        const HEAP = this.fInstance.memory.buffer;
        const HEAP32 = new Int32Array(HEAP);
        const HEAPF =
            this.fSampleSize === 4
                ? new Float32Array(HEAP)
                : new Float64Array(HEAP);

        if (this.getNumInputs() > 0) {
            for (let chan = 0; chan < this.getNumInputs(); chan++) {
                HEAP32[(this.fAudioInputs >> 2) + chan] =
                    $audioInputs + this.fBufferSize * this.fSampleSize * chan;
            }
            // Prepare Ins buffer tables
            const dspInChans = HEAP32.subarray(
                this.fAudioInputs >> 2,
                (this.fAudioInputs + this.getNumInputs() * this.fPtrSize) >> 2
            );
            for (let chan = 0; chan < this.getNumInputs(); chan++) {
                this.fInChannels[chan] = HEAPF.subarray(
                    dspInChans[chan] >> Math.log2(this.fSampleSize),
                    (dspInChans[chan] + this.fBufferSize * this.fSampleSize) >>
                        Math.log2(this.fSampleSize)
                );
            }
        }
        if (this.getNumOutputs() > 0) {
            for (let chan = 0; chan < this.getNumOutputs(); chan++) {
                HEAP32[(this.fAudioOutputs >> 2) + chan] =
                    $audioOutputs + this.fBufferSize * this.fSampleSize * chan;
            }
            // Prepare Out buffer tables
            const dspOutChans = HEAP32.subarray(
                this.fAudioOutputs >> 2,
                (this.fAudioOutputs + this.getNumOutputs() * this.fPtrSize) >> 2
            );
            for (let chan = 0; chan < this.getNumOutputs(); chan++) {
                this.fOutChannels[chan] = HEAPF.subarray(
                    dspOutChans[chan] >> Math.log2(this.fSampleSize),
                    (dspOutChans[chan] + this.fBufferSize * this.fSampleSize) >>
                        Math.log2(this.fSampleSize)
                );
            }
        }

        // Record where each channel starts: `setBufferOffset` overwrites the
        // tables between slices, so they stop being a record of that.
        this.fHEAP32 = HEAP32;
        this.fInBase = [];
        for (let chan = 0; chan < this.getNumInputs(); chan++) {
            this.fInBase[chan] = HEAP32[(this.fAudioInputs >> 2) + chan];
        }
        this.fOutBase = [];
        for (let chan = 0; chan < this.getNumOutputs(); chan++) {
            this.fOutBase[chan] = HEAP32[(this.fAudioOutputs >> 2) + chan];
        }

        return endMemory;
    }

    toString() {
        return `============== Mono Memory layout ==============
        this.fBufferSize: ${this.fBufferSize}
        this.fJSONDsp.size: ${this.fJSONDsp.size}
        this.fAudioInputs: ${this.fAudioInputs}
        this.fAudioOutputs: ${this.fAudioOutputs}
        this.fDSP: ${this.fDSP}`;
    }

    // Public API
    compute(
        input:
            Float32Array[] | ((input: Float32Array[] | Float64Array[]) => void),
        output:
            | Float32Array[]
            | ((output: Float32Array[] | Float64Array[]) => void),
        events?: FaustTimedEvent[]
    ) {
        // Check DSP state
        if (this.fDestroyed) return false;

        // Check Processing state: the node returns 'true' to stay in the graph, even if not processing
        if (!this.fProcessing) {
            this.applyEvents(events);
            return true;
        }

        // Init memory again on first call (since WebAssembly.memory.grow() may have been called)
        if (this.fFirstCall) {
            this.initMemory();
            this.fFirstCall = false;
        }

        if (typeof input === 'function') {
            // Call input callback to avoid array copy
            input(this.fInChannels);
        } else {
            // Check inputs
            if (
                this.getNumInputs() > 0 &&
                (!input || !input[0] || input[0].length === 0)
            ) {
                // console.log("Process input error");
                this.applyEvents(events);
                return true;
            }

            // Check outputs
            if (
                this.getNumOutputs() > 0 &&
                typeof output !== 'function' &&
                (!output || !output[0] || output[0].length === 0)
            ) {
                // console.log("Process output error");
                this.applyEvents(events);
                return true;
            }

            // Copy inputs
            if (input !== undefined) {
                for (
                    let chan = 0;
                    chan < Math.min(this.getNumInputs(), input.length);
                    chan++
                ) {
                    const dspInput = this.fInChannels[chan];
                    dspInput.set(input[chan]);
                }
            }
        }
        // Possibly call an externally given callback (for instance to synchronize playing a MIDIFile...)
        if (this.fComputeHandler) this.fComputeHandler(this.fBufferSize);

        // Compute -- in slices around the events, if there are any
        this.renderBlock(events, this.fRenderSlice);

        // Update bargraph
        this.updateOutputs();

        // No NaN or Inf leaves the DSP
        this.clearNonFinite();

        let forPlot = this.fOutChannels;
        if (typeof output === 'function') {
            // Call output callback to avoid array copy
            output(this.fOutChannels);
        } else {
            // Copy outputs
            for (
                let chan = 0;
                chan < Math.min(this.getNumOutputs(), output.length);
                chan++
            ) {
                const dspOutput = this.fOutChannels[chan];
                output[chan].set(dspOutput);
                // console.log("chan: " + chan + " output: " + dspOutput[0]);
            }
            forPlot = output;
        }

        // PlotHandler handling
        if (this.fPlotHandler) {
            this.fPlotHandler(
                forPlot,
                this.fBufferNum++,
                this.fCachedEvents.length ? this.fCachedEvents : undefined
            );
            this.fCachedEvents = [];
        }

        return true;
    }

    metadata(handler: MetadataHandler) {
        super.metadata(handler);
    }

    getNumInputs() {
        return this.fInstance.api.getNumInputs(this.fDSP);
    }
    getNumOutputs() {
        return this.fInstance.api.getNumOutputs(this.fDSP);
    }

    setParamValue(path: string, value: number) {
        // A path that is not in the table used to reach wasm as `undefined`,
        // which the binding coerces to offset 0: a typo, or a path kept from
        // an older version of the DSP, silently wrote over the head of the
        // DSP struct and came back out as a full-scale spike.
        const index = this.fPathTable[path];
        if (index === undefined) return this.warnUnknownPath(path, 'ignored');
        if (this.fPlotHandler)
            this.fCachedEvents.push({ type: 'param', data: { path, value } });
        this.fInstance.api.setParamValue(this.fDSP, index, value);
        this.callInputParamHandler(path, this.getParamValue(path));
    }
    getParamValue(path: string) {
        const index = this.fPathTable[path];
        if (index === undefined) {
            this.warnUnknownPath(path, 'returning 0');
            return 0;
        }
        return this.fInstance.api.getParamValue(this.fDSP, index);
    }

    getMeta() {
        return this.fJSONDsp;
    }
    getJSON() {
        return this.fInstance.json;
    }
    getDescriptors() {
        return this.fDescriptor;
    }
    getUI() {
        return this.fJSONDsp.ui;
    }
}

export class FaustWebAudioDspVoice {
    // Voice state
    static get kActiveVoice() {
        return 0;
    }
    static get kFreeVoice() {
        return -1;
    }
    static get kReleaseVoice() {
        return -2;
    }
    static get kLegatoVoice() {
        return -3;
    }
    static get kNoVoice() {
        return -4;
    }
    static get VOICE_STOP_LEVEL() {
        return 0.00003162;
    } // -90 db

    private fFreqLabel: number[] = [];
    private fGateLabel: number[] = [];
    private fGainLabel: number[] = [];
    private fKeyLabel: number[] = [];
    private fVelLabel: number[] = [];
    private fDSP: number; // Voice DSP location in wasm memory
    private fAPI: IFaustDspInstance; // Voice DSP code
    private fSampleRate: number;
    // Accessed by PolyDSPImp class
    fCurNote = FaustWebAudioDspVoice.kFreeVoice;
    fNextNote = -1;
    fNextVel = -1;
    // MIDI channel (0..15) of the current note, of the next one in kLegatoVoice state
    fChannel = 0;
    fDate = 0;
    fLevel = 0;

    constructor(
        $dsp: number,
        api: IFaustDspInstance,
        inputItems: string[],
        pathTable: { [address: string]: number },
        sampleRate: number
    ) {
        this.fDSP = $dsp;
        this.fAPI = api;
        this.fSampleRate = sampleRate;
        this.init(sampleRate);
        this.extractPaths(inputItems, pathTable);
    }

    static midiToFreq(note: number) {
        return 440.0 * 2 ** ((note - 69) / 12);
    }

    static normalizeVelocity(velocity: number) {
        return velocity / 127.0;
    }

    init(sampleRate: number) {
        this.fAPI.init(this.fDSP, sampleRate);
    }

    instanceInit() {
        this.fAPI.instanceInit(this.fDSP, this.fSampleRate);
    }

    instanceClear() {
        this.fAPI.instanceClear(this.fDSP);
    }

    instanceConstants() {
        this.fAPI.instanceConstants(this.fDSP, this.fSampleRate);
    }

    instanceResetUserInterface() {
        this.fAPI.instanceResetUserInterface(this.fDSP);
    }

    private extractPaths(
        inputItems: string[],
        pathTable: { [address: string]: number }
    ) {
        inputItems.forEach((item) => {
            if (item.endsWith('/gate')) {
                this.fGateLabel.push(pathTable[item]);
            } else if (item.endsWith('/freq')) {
                this.fFreqLabel.push(pathTable[item]);
            } else if (item.endsWith('/key')) {
                this.fKeyLabel.push(pathTable[item]);
            } else if (item.endsWith('/gain')) {
                this.fGainLabel.push(pathTable[item]);
            } else if (item.endsWith('/vel') || item.endsWith('/velocity')) {
                this.fVelLabel.push(pathTable[item]);
            }
        });
    }

    // Public API
    keyOn(pitch: number, velocity: number, legato: boolean = false) {
        if (legato) {
            this.fNextNote = pitch;
            this.fNextVel = velocity;
        } else {
            this.fFreqLabel.forEach((index) =>
                this.fAPI.setParamValue(
                    this.fDSP,
                    index,
                    FaustWebAudioDspVoice.midiToFreq(pitch)
                )
            );
            this.fGateLabel.forEach((index) =>
                this.fAPI.setParamValue(this.fDSP, index, 1)
            );
            this.fGainLabel.forEach((index) =>
                this.fAPI.setParamValue(
                    this.fDSP,
                    index,
                    FaustWebAudioDspVoice.normalizeVelocity(velocity)
                )
            );
            this.fKeyLabel.forEach((index) =>
                this.fAPI.setParamValue(this.fDSP, index, pitch)
            );
            this.fVelLabel.forEach((index) =>
                this.fAPI.setParamValue(this.fDSP, index, velocity)
            );
            // Keep pitch
            this.fCurNote = pitch;
        }
    }

    keyOff(hard: boolean = false) {
        this.fGateLabel.forEach((index) =>
            this.fAPI.setParamValue(this.fDSP, index, 0)
        );
        if (hard) {
            this.fCurNote = FaustWebAudioDspVoice.kFreeVoice;
        } else {
            this.fCurNote = FaustWebAudioDspVoice.kReleaseVoice;
        }
    }

    computeLegato(
        bufferSize: number,
        $inputs: number,
        $outputZero: number,
        $outputsHalf: number
    ) {
        // `>> 1` rather than `/ 2` because `bufferSize` need not be even, and
        // wasm counts whole frames. The second half takes the remainder.
        const size = bufferSize >> 1;

        // Reset envelops
        this.fGateLabel.forEach((index) =>
            this.fAPI.setParamValue(this.fDSP, index, 0)
        );

        // Compute current voice on half buffer
        this.fAPI.compute(this.fDSP, size, $inputs, $outputZero);

        // Start next keyOn
        this.keyOn(this.fNextNote, this.fNextVel);

        // Compute on second half buffer
        this.fAPI.compute(this.fDSP, bufferSize - size, $inputs, $outputsHalf);
    }

    compute(bufferSize: number, $inputs: number, $outputs: number) {
        this.fAPI.compute(this.fDSP, bufferSize, $inputs, $outputs);
    }

    setParamValue(index: number, value: number) {
        this.fAPI.setParamValue(this.fDSP, index, value);
    }
    getParamValue(index: number) {
        return this.fAPI.getParamValue(this.fDSP, index);
    }
}

export class FaustPolyWebAudioDsp
    extends FaustBaseWebAudioDsp
    implements IFaustPolyWebAudioDsp
{
    private fInstance: FaustPolyDspInstance;
    private fEffect!: number;
    private fJSONEffect: FaustDspMeta | null;
    private fAudioMixing!: number;
    private fAudioMixingHalf!: number;
    private fMixingBase: number[] = [];
    /** Float view of the memory, kept from `initMemory` like `fHEAP32`. */
    private fHEAPF!: Float32Array | Float64Array;
    private fVoiceTable: FaustWebAudioDspVoice[];
    private fSampleRate: number;

    /** Voices whose crossfade this block already rendered in full. */
    private fStolen: FaustWebAudioDspVoice[] = [];

    /** The count last given to `fActiveVoicesHandler`. */
    private fActiveVoices = 0;
    private fActiveVoicesHandler: ActiveVoicesHandler | null = null;

    /**
     * Render one slice: every live voice into the sum, then the effect.
     *
     * The mixer, the voices and the effect all take a frame count, so a slice
     * is the same work over fewer frames. A field rather than an inline
     * closure so it is allocated once instead of on every `compute` call.
     *
     * Two things `compute` does around this. The sum is cleared once for the
     * block, not per slice, because `renderStolenVoices` has already written
     * across the whole of it. And those stolen voices are skipped here.
     *
     * A voice that becomes `kLegatoVoice` partway through the block is not one
     * of them: it plays out the note it is losing and crossfades at the top of
     * the next block, as it did when a `keyOn` could only arrive between
     * blocks.
     */
    private fRenderSlice = (offset: number, count: number) => {
        this.setBufferOffset(offset);
        this.setMixingOffset(offset, count);
        this.fVoiceTable.forEach((voice) => {
            if (voice.fCurNote === FaustWebAudioDspVoice.kFreeVoice) return;
            if (this.fStolen.length && this.fStolen.indexOf(voice) !== -1)
                return;
            // Compute current note
            voice.compute(count, this.fAudioInputs, this.fAudioMixing);
            // Mix it in result
            const level = this.fInstance.mixerAPI.mixCheckVoice(
                count,
                this.getNumOutputs(),
                this.fAudioMixing,
                this.fAudioOutputs
            );
            // Keep the loudest level from any slice. A few frames landing on
            // a zero crossing read near silence from a voice that is still
            // sounding, so `compute` decides whether a release has finished
            // once the whole block is done.
            if (level > voice.fLevel) voice.fLevel = level;
        });
        if (this.fInstance.effectAPI)
            this.fInstance.effectAPI.compute(
                this.fEffect,
                count,
                this.fAudioOutputs,
                this.fAudioOutputs
            );
    };

    /**
     * Render the stolen voices, each across the whole block.
     *
     * A steal is a hand-over: the voice plays the note it is losing over the
     * first half of the buffer, that half fades out, and the new note plays
     * the second half, faded in. Both fades are needed. `fadeOut` scales the
     * buffer, not the voice: after `keyOn` the DSP carries on from its live
     * state -- an envelope that never reached silence is still up -- so
     * without the fade-in the second half started at full level, a step on
     * every stolen note. On a monophonic patch whose voice never falls
     * silent that is a click on every note after the first (measured on a
     * long-release bass: 0, 0, 0, 0.1485, 0.2618 across the split).
     *
     * The fades have to be half a block -- 64 frames -- rather than half a
     * slice, which late in the block would be a frame or two, or nothing at
     * all. So this runs before the slicing, and `fRenderSlice` skips these
     * voices.
     */
    private renderStolenVoices() {
        const stolen = this.fStolen;
        stolen.length = 0;
        this.fVoiceTable.forEach((voice) => {
            if (voice.fCurNote !== FaustWebAudioDspVoice.kLegatoVoice) return;
            stolen.push(voice);
            // Play from current note and next note
            voice.computeLegato(
                this.fBufferSize,
                this.fAudioInputs,
                this.fAudioMixing,
                this.fAudioMixingHalf
            );
            // FadeOut on first half buffer
            this.fInstance.mixerAPI.fadeOut(
                this.fBufferSize >> 1,
                this.getNumOutputs(),
                this.fAudioMixing
            );
            // FadeIn on second half buffer, the mirror of fadeOut: 1/count
            // up to 1. `computeLegato` gives an odd count's extra frame to
            // the second half, so it is measured from the split, not halved.
            this.fadeIn(
                this.fBufferSize - (this.fBufferSize >> 1),
                this.getNumOutputs(),
                this.fAudioMixingHalf
            );
            // Mix it in result
            voice.fLevel = this.fInstance.mixerAPI.mixCheckVoice(
                this.fBufferSize,
                this.getNumOutputs(),
                this.fAudioMixing,
                this.fAudioOutputs
            );
        });
    }

    /**
     * Scale `count` frames of each channel at `$tables` from 1/count up to 1.
     *
     * The mixer has `fadeOut` in wasm; this is its counterpart on the JS
     * side, over the channel-pointer table the same way the mixer reads it.
     */
    private fadeIn(count: number, chans: number, $tables: number) {
        const shift = Math.log2(this.fSampleSize);
        const HEAPF = this.fHEAPF;
        for (let chan = 0; chan < chans; chan++) {
            const start = this.fHEAP32[($tables >> 2) + chan] >> shift;
            for (let i = 0; i < count; i++) {
                HEAPF[start + i] *= (i + 1) / count;
            }
        }
    }

    /**
     * Move the mixing tables along with the input and output ones.
     *
     * `fAudioMixing` is where a voice renders before being summed into the
     * output, so it follows the slice. `fAudioMixingHalf` is the crossfade
     * split point, `count >> 1` frames in, matching `computeLegato`. Only
     * `renderStolenVoices` uses it, and always with the whole block.
     */
    private setMixingOffset(offset: number, count: number) {
        const bytes = offset * this.fSampleSize;
        const half = (offset + (count >> 1)) * this.fSampleSize;
        for (let chan = 0; chan < this.fMixingBase.length; chan++) {
            this.fHEAP32[(this.fAudioMixing >> 2) + chan] =
                this.fMixingBase[chan] + bytes;
            this.fHEAP32[(this.fAudioMixingHalf >> 2) + chan] =
                this.fMixingBase[chan] + half;
        }
    }

    constructor(
        instance: FaustPolyDspInstance,
        sampleRate: number,
        sampleSize: number,
        bufferSize: number,
        soundfiles: LooseFaustDspFactory['soundfiles']
    ) {
        super(sampleSize, bufferSize, soundfiles);
        this.fInstance = instance;
        this.fSampleRate = sampleRate;

        // Create JSON for voice
        this.fJSONDsp = JSON.parse(this.fInstance.voiceJSON);
        this.fMidiChannel = FaustBaseWebAudioDsp.parseMidiChannel(
            this.fJSONDsp.meta
        );

        // Create JSON for effect
        this.fJSONEffect =
            this.fInstance.effectAPI && this.fInstance.effectJSON
                ? JSON.parse(this.fInstance.effectJSON)
                : null;

        // Setup GUI
        FaustBaseWebAudioDsp.parseUI(this.fJSONDsp.ui, this.fUICallback);
        if (this.fJSONEffect)
            FaustBaseWebAudioDsp.parseUI(this.fJSONEffect.ui, this.fUICallback);

        // Setup wasm memory
        this.fEndMemory = this.initMemory();

        // Init DSP voices
        this.fVoiceTable = [];
        for (let voice = 0; voice < this.fInstance.voices; voice++) {
            this.fVoiceTable.push(
                new FaustWebAudioDspVoice(
                    this.fJSONDsp.size * voice,
                    this.fInstance.voiceAPI,
                    this.fInputsItems,
                    this.fPathTable,
                    sampleRate
                )
            );
        }

        // Init effect
        if (this.fInstance.effectAPI)
            this.fInstance.effectAPI.init(this.fEffect, sampleRate);

        // Init soundfiles memory is needed
        if (this.fSoundfiles.length > 0) {
            // Create memory allocator for soundfiles in wasm memory, starting at the end of DSP memory
            const allocator = new WasmAllocator(
                this.fInstance.memory,
                this.fEndMemory
            );
            // Init soundfiles memory for all voices
            for (let voice = 0; voice < this.fInstance.voices; voice++) {
                this.initSoundfileMemory(allocator, this.fJSONDsp.size * voice);
            }
        }
    }

    init() {
        this.fVoiceTable.forEach((voice) => voice.init(this.fSampleRate));
        if (this.fInstance.effectAPI)
            this.fInstance.effectAPI.init(this.fEffect, this.fSampleRate);
    }

    instanceInit() {
        this.fVoiceTable.forEach((voice) => voice.instanceInit());
        if (this.fInstance.effectAPI)
            this.fInstance.effectAPI.instanceInit(
                this.fEffect,
                this.fSampleRate
            );
    }

    instanceClear() {
        this.fVoiceTable.forEach((voice) => voice.instanceClear());
        if (this.fInstance.effectAPI)
            this.fInstance.effectAPI.instanceClear(this.fEffect);
    }

    instanceConstants() {
        this.fVoiceTable.forEach((voice) => voice.instanceConstants());
        if (this.fInstance.effectAPI)
            this.fInstance.effectAPI.instanceConstants(
                this.fEffect,
                this.fSampleRate
            );
    }

    instanceResetUserInterface() {
        this.fVoiceTable.forEach((voice) => voice.instanceResetUserInterface());
        if (this.fInstance.effectAPI)
            this.fInstance.effectAPI.instanceResetUserInterface(this.fEffect);
    }

    private initMemory() {
        // Effet start at the end of all DSP voices
        this.fEffect = this.fJSONDsp.size * this.fInstance.voices;

        // Audio buffer start at the end of effect
        const $audio =
            this.fEffect + (this.fJSONEffect ? this.fJSONEffect.size : 0);

        // Setup audio pointers offset
        this.fAudioInputs = $audio;
        this.fAudioOutputs =
            this.fAudioInputs + this.getNumInputs() * this.fPtrSize;
        this.fAudioMixing =
            this.fAudioOutputs + this.getNumOutputs() * this.fPtrSize;
        this.fAudioMixingHalf =
            this.fAudioMixing + this.getNumOutputs() * this.fPtrSize;

        // Prepare wasm memory layout
        const $audioInputs =
            this.fAudioMixingHalf + this.getNumOutputs() * this.fPtrSize;
        const $audioOutputs =
            $audioInputs +
            this.getNumInputs() * this.fBufferSize * this.fSampleSize;
        const $audioMixing =
            $audioOutputs +
            this.getNumOutputs() * this.fBufferSize * this.fSampleSize;

        // Compute memory end in bytes
        const endMemory =
            $audioMixing +
            this.getNumOutputs() * this.fBufferSize * this.fSampleSize;

        // Setup Int32 and Real views of the memory
        const HEAP = this.fInstance.memory.buffer;
        const HEAP32 = new Int32Array(HEAP);
        const HEAPF =
            this.fSampleSize === 4
                ? new Float32Array(HEAP)
                : new Float64Array(HEAP);

        if (this.getNumInputs() > 0) {
            for (let chan = 0; chan < this.getNumInputs(); chan++) {
                HEAP32[(this.fAudioInputs >> 2) + chan] =
                    $audioInputs + this.fBufferSize * this.fSampleSize * chan;
            }
            // Prepare Ins buffer tables
            const dspInChans = HEAP32.subarray(
                this.fAudioInputs >> 2,
                (this.fAudioInputs + this.getNumInputs() * this.fPtrSize) >> 2
            );
            for (let chan = 0; chan < this.getNumInputs(); chan++) {
                this.fInChannels[chan] = HEAPF.subarray(
                    dspInChans[chan] >> Math.log2(this.fSampleSize),
                    (dspInChans[chan] + this.fBufferSize * this.fSampleSize) >>
                        Math.log2(this.fSampleSize)
                );
            }
        }
        if (this.getNumOutputs() > 0) {
            for (let chan = 0; chan < this.getNumOutputs(); chan++) {
                HEAP32[(this.fAudioOutputs >> 2) + chan] =
                    $audioOutputs + this.fBufferSize * this.fSampleSize * chan;
                HEAP32[(this.fAudioMixing >> 2) + chan] =
                    $audioMixing + this.fBufferSize * this.fSampleSize * chan;
                HEAP32[(this.fAudioMixingHalf >> 2) + chan] =
                    $audioMixing +
                    this.fBufferSize * this.fSampleSize * chan +
                    (this.fBufferSize / 2) * this.fSampleSize;
            }
            // Prepare Out buffer tables
            const dspOutChans = HEAP32.subarray(
                this.fAudioOutputs >> 2,
                (this.fAudioOutputs + this.getNumOutputs() * this.fPtrSize) >> 2
            );
            for (let chan = 0; chan < this.getNumOutputs(); chan++) {
                this.fOutChannels[chan] = HEAPF.subarray(
                    dspOutChans[chan] >> Math.log2(this.fSampleSize),
                    (dspOutChans[chan] + this.fBufferSize * this.fSampleSize) >>
                        Math.log2(this.fSampleSize)
                );
            }
        }

        // Record where each channel starts: `setBufferOffset` overwrites the
        // tables between slices, so they stop being a record of that.
        this.fHEAP32 = HEAP32;
        this.fInBase = [];
        for (let chan = 0; chan < this.getNumInputs(); chan++) {
            this.fInBase[chan] = HEAP32[(this.fAudioInputs >> 2) + chan];
        }
        this.fHEAPF = HEAPF;
        this.fOutBase = [];
        this.fMixingBase = [];
        for (let chan = 0; chan < this.getNumOutputs(); chan++) {
            this.fOutBase[chan] = HEAP32[(this.fAudioOutputs >> 2) + chan];
            this.fMixingBase[chan] = HEAP32[(this.fAudioMixing >> 2) + chan];
        }

        return endMemory;
    }

    toString() {
        return `============== Poly Memory layout ==============
        this.fBufferSize: ${this.fBufferSize}
        this.fJSONDsp.size: ${this.fJSONDsp.size}
        this.fAudioInputs: ${this.fAudioInputs}
        this.fAudioOutputs: ${this.fAudioOutputs}
        this.fAudioMixing: ${this.fAudioMixing}
        this.fAudioMixingHalf: ${this.fAudioMixingHalf}`;
    }

    /**
     * When each voice was last allocated, as one global monotonic date.
     *
     * Incrementing the voice's own `fDate` instead, as this used to, made the
     * date a per-slot reuse counter: notes played and released before a chord
     * kept reusing slot 0 and inflating only its date, and when the chord
     * then overflowed the pool, the allocator considered a younger note
     * "oldest" and stole the wrong voice.
     */
    private fDate = 0;

    private allocVoice(voice: number, type: number) {
        this.fVoiceTable[voice].fDate = this.fDate++;
        this.fVoiceTable[voice].fCurNote = type;
        return voice;
    }

    // The same pitch may be played on several channels at once: a note off
    // releases the voice of its own channel
    private getPlayingVoice(channel: number, pitch: number) {
        let voicePlaying = FaustWebAudioDspVoice.kNoVoice;
        let oldestDatePlaying = Number.MAX_VALUE;

        for (let i = 0; i < this.fInstance.voices; i++) {
            if (this.fVoiceTable[i].fChannel !== channel) continue;
            const curNote = this.fVoiceTable[i].fCurNote;
            const nextNote = this.fVoiceTable[i].fNextNote;

            if (
                curNote === pitch ||
                (curNote === FaustWebAudioDspVoice.kLegatoVoice &&
                    nextNote === pitch)
            ) {
                // Keeps oldest playing voice
                if (this.fVoiceTable[i].fDate < oldestDatePlaying) {
                    oldestDatePlaying = this.fVoiceTable[i].fDate;
                    voicePlaying = i;
                }
            }
        }
        return voicePlaying;
    }

    private getFreeVoice() {
        for (let voice = 0; voice < this.fInstance.voices; voice++) {
            if (
                this.fVoiceTable[voice].fCurNote ===
                FaustWebAudioDspVoice.kFreeVoice
            ) {
                return this.allocVoice(
                    voice,
                    FaustWebAudioDspVoice.kActiveVoice
                );
            }
        }

        let voiceRelease = FaustWebAudioDspVoice.kNoVoice;
        let voicePlaying = FaustWebAudioDspVoice.kNoVoice;
        let oldestDateRelease = Number.MAX_VALUE;
        let oldestDatePlaying = Number.MAX_VALUE;

        for (let voice = 0; voice < this.fInstance.voices; voice++) {
            // Scan all voices
            // Try to steal a voice in DspVoice.kReleaseVoice mode...
            if (
                this.fVoiceTable[voice].fCurNote ===
                FaustWebAudioDspVoice.kReleaseVoice
            ) {
                // Keeps oldest release voice
                if (this.fVoiceTable[voice].fDate < oldestDateRelease) {
                    oldestDateRelease = this.fVoiceTable[voice].fDate;
                    voiceRelease = voice;
                }
            } else if (this.fVoiceTable[voice].fDate < oldestDatePlaying) {
                oldestDatePlaying = this.fVoiceTable[voice].fDate;
                voicePlaying = voice;
            }
        }
        // Then decide which one to steal
        if (oldestDateRelease !== Number.MAX_VALUE) {
            console.log(
                `Steal release voice : voice_date = ${this.fVoiceTable[voiceRelease].fDate} voice = ${voiceRelease}`
            );
            return this.allocVoice(
                voiceRelease,
                FaustWebAudioDspVoice.kLegatoVoice
            );
        }
        if (oldestDatePlaying !== Number.MAX_VALUE) {
            console.log(
                `Steal playing voice : voice_date = ${this.fVoiceTable[voicePlaying].fDate} voice = ${voicePlaying}`
            );
            return this.allocVoice(
                voicePlaying,
                FaustWebAudioDspVoice.kLegatoVoice
            );
        }
        return FaustWebAudioDspVoice.kNoVoice;
    }

    // Public API
    compute(
        input: Float32Array[],
        output: Float32Array[],
        events?: FaustTimedEvent[]
    ) {
        // Check DSP state
        if (this.fDestroyed) return false;

        // Init memory again on first call (since WebAssembly.memory.grow() may have been called)
        if (this.fFirstCall) {
            this.initMemory();
            this.fFirstCall = false;
        }

        // Check Processing state: the node returns 'true' to stay in the graph, even if not processing
        if (!this.fProcessing) {
            this.applyEvents(events);
            return true;
        }

        // Check inputs
        if (
            this.getNumInputs() > 0 &&
            (!input || !input[0] || input[0].length === 0)
        ) {
            // console.log("Process input error");
            this.applyEvents(events);
            return true;
        }

        // Check outputs
        if (
            this.getNumOutputs() > 0 &&
            (!output || !output[0] || output[0].length === 0)
        ) {
            // console.log("Process output error");
            this.applyEvents(events);
            return true;
        }

        // Copy inputs
        if (input !== undefined) {
            for (
                let chan = 0;
                chan < Math.min(this.getNumInputs(), input.length);
                ++chan
            ) {
                const dspInput = this.fInChannels[chan];
                dspInput.set(input[chan]);
            }
        }

        // Possibly call an externally given callback (for instance to synchronize playing a MIDIFile...)
        if (this.fComputeHandler) this.fComputeHandler(this.fBufferSize);

        // Clear the sum once for the block, not per slice: the stolen voices
        // below write across the whole of it, and a slice clearing its own
        // range afterwards would erase part of that.
        this.setBufferOffset(0);
        this.setMixingOffset(0, this.fBufferSize);
        this.fInstance.mixerAPI.clearOutput(
            this.fBufferSize,
            this.getNumOutputs(),
            this.fAudioOutputs
        );
        this.fVoiceTable.forEach((voice) => (voice.fLevel = 0));
        this.renderStolenVoices();

        // Compute -- in slices around the events, if there are any
        this.renderBlock(events, this.fRenderSlice);

        // A releasing voice that stayed below the threshold for every slice
        // has died away, and its slot is free again.
        this.fVoiceTable.forEach((voice) => {
            if (
                voice.fCurNote === FaustWebAudioDspVoice.kReleaseVoice &&
                voice.fLevel < FaustWebAudioDspVoice.VOICE_STOP_LEVEL
            ) {
                voice.fCurNote = FaustWebAudioDspVoice.kFreeVoice;
            }
        });

        // Report the number of sounding voices, once the freed ones are known,
        // only when it changed: at most two calls per note
        if (this.fActiveVoicesHandler) {
            const active = this.getNumActiveVoices();
            if (active !== this.fActiveVoices) {
                this.fActiveVoices = active;
                this.fActiveVoicesHandler(active);
            }
        }

        // Update bargraph
        this.updateOutputs();

        // No NaN or Inf leaves the DSP
        this.clearNonFinite();

        if (output !== undefined) {
            // Copy outputs
            for (
                let chan = 0;
                chan < Math.min(this.getNumOutputs(), output.length);
                chan++
            ) {
                const dspOutput = this.fOutChannels[chan];
                output[chan].set(dspOutput);
            }

            // PlotHandler handling
            if (this.fPlotHandler) {
                this.fPlotHandler(
                    output,
                    this.fBufferNum++,
                    this.fCachedEvents.length ? this.fCachedEvents : undefined
                );
                this.fCachedEvents = [];
            }
        }

        return true;
    }

    getNumInputs() {
        return this.fInstance.voiceAPI.getNumInputs(0);
    }
    getNumOutputs() {
        return this.fInstance.voiceAPI.getNumOutputs(0);
    }

    private static findPath(o: any, p: string) {
        if (typeof o !== 'object') {
            return false;
        } else if (o.address) {
            return o.address === p;
        } else {
            for (const k in o) {
                if (FaustPolyWebAudioDsp.findPath(o[k], p)) return true;
            }
            return false;
        }
    }

    setParamValue(path: string, value: number) {
        // Same guard as the mono case, and it matters more here: an unknown
        // path fell through to the voice branch and wrote offset 0 of every
        // voice at once. Effect parameters are in the table too -- the effect
        // UI is parsed into it in the constructor -- so this rejects only
        // paths that belong to neither.
        const index = this.fPathTable[path];
        if (index === undefined) return this.warnUnknownPath(path, 'ignored');
        if (this.fPlotHandler)
            this.fCachedEvents.push({ type: 'param', data: { path, value } });
        if (
            this.fJSONEffect &&
            FaustPolyWebAudioDsp.findPath(this.fJSONEffect.ui, path) &&
            this.fInstance.effectAPI
        ) {
            this.fInstance.effectAPI.setParamValue(this.fEffect, index, value);
        } else {
            this.fVoiceTable.forEach((voice) =>
                voice.setParamValue(index, value)
            );
        }
        this.callInputParamHandler(path, this.getParamValue(path));
    }
    getParamValue(path: string) {
        const index = this.fPathTable[path];
        if (index === undefined) {
            this.warnUnknownPath(path, 'returning 0');
            return 0;
        }
        if (
            this.fJSONEffect &&
            FaustPolyWebAudioDsp.findPath(this.fJSONEffect.ui, path) &&
            this.fInstance.effectAPI
        ) {
            return this.fInstance.effectAPI.getParamValue(this.fEffect, index);
        } else {
            return this.fVoiceTable[0].getParamValue(index);
        }
    }

    getMeta() {
        const o = this.fJSONDsp;
        const e = this.fJSONEffect;
        const r = { ...o };
        if (e) {
            r.ui = [
                {
                    type: 'tgroup',
                    label: 'Sequencer',
                    items: [
                        { type: 'vgroup', label: 'Instrument', items: o.ui },
                        { type: 'vgroup', label: 'Effect', items: e.ui }
                    ]
                }
            ];
        } else {
            r.ui = [
                {
                    type: 'tgroup',
                    label: 'Polyphonic',
                    items: [{ type: 'vgroup', label: 'Voices', items: o.ui }]
                }
            ];
        }
        return r as FaustDspMeta;
    }

    getJSON() {
        return JSON.stringify(this.getMeta());
    }

    getUI() {
        return this.getMeta().ui;
    }

    getDescriptors() {
        return this.fDescriptor;
    }

    midiMessage(data: number[] | Uint8Array) {
        if (!this.acceptMidiStatus(data[0])) return;
        const cmd = data[0] >> 4;
        const channel = data[0] & 0xf;
        const data1 = data[1];
        const data2 = data[2];
        if (cmd === 8 || (cmd === 9 && data2 === 0))
            return this.keyOff(channel, data1, data2);
        else if (cmd === 9) return this.keyOn(channel, data1, data2);
        else super.midiMessage(data);
    }

    // Channel mode messages only end the voices started on their channel, as
    // in the C++ poly-dsp.h: All Notes Off releases them, All Sound Off mutes
    // them at once
    ctrlChange(channel: number, ctrl: number, value: number) {
        if (ctrl === 123) {
            this.channelNotesOff(channel, false);
        } else if (ctrl === 120) {
            this.channelNotesOff(channel, true);
        } else {
            super.ctrlChange(channel, ctrl, value);
        }
    }

    // An indexed loop: reachable from the audio thread, it must not allocate
    private channelNotesOff(channel: number, hard: boolean) {
        if (this.fPlotHandler)
            this.fCachedEvents.push({
                type: 'ctrlChange',
                data: [channel, hard ? 120 : 123, 0]
            });
        for (let i = 0; i < this.fVoiceTable.length; i++) {
            const voice = this.fVoiceTable[i];
            if (
                voice.fChannel === channel &&
                voice.fCurNote !== FaustWebAudioDspVoice.kFreeVoice
            )
                voice.keyOff(hard);
        }
    }

    keyOn(channel: number, pitch: number, velocity: number) {
        if (this.fPlotHandler)
            this.fCachedEvents.push({
                type: 'keyOn',
                data: [channel, pitch, velocity]
            });
        const voice = this.getFreeVoice();
        this.fVoiceTable[voice].fChannel = channel;
        this.fVoiceTable[voice].keyOn(
            pitch,
            velocity,
            this.fVoiceTable[voice].fCurNote ==
                FaustWebAudioDspVoice.kLegatoVoice
        );
    }

    keyOff(channel: number, pitch: number, velocity: number) {
        if (this.fPlotHandler)
            this.fCachedEvents.push({
                type: 'keyOff',
                data: [channel, pitch, velocity]
            });
        const voice = this.getPlayingVoice(channel, pitch);
        if (voice !== FaustWebAudioDspVoice.kNoVoice) {
            this.fVoiceTable[voice].keyOff();
        } else {
            console.log('Playing pitch = %d not found\n', pitch);
        }
    }

    allNotesOff(hard: boolean = true) {
        this.fCachedEvents.push({ type: 'ctrlChange', data: [0, 123, 0] });
        this.fVoiceTable.forEach((voice) => voice.keyOff(hard));
    }

    // Same count as dsp_voice_group::getNumActiveVoices() in the C++ poly-dsp.h.
    // An indexed loop: called after every block when a handler is set, it must
    // not allocate an iterator.
    getNumActiveVoices() {
        let count = 0;
        for (let i = 0; i < this.fVoiceTable.length; i++) {
            if (
                this.fVoiceTable[i].fCurNote !==
                FaustWebAudioDspVoice.kFreeVoice
            )
                count++;
        }
        return count;
    }

    /**
     * Call `handler` with the number of sounding voices after each block in
     * which it changed (see `getNumActiveVoices`). The AudioWorklet processor
     * uses it to keep its node's count up to date.
     */
    setActiveVoicesHandler(handler: ActiveVoicesHandler | null) {
        this.fActiveVoicesHandler = handler;
        this.fActiveVoices = this.getNumActiveVoices();
    }
    getActiveVoicesHandler() {
        return this.fActiveVoicesHandler;
    }
}
