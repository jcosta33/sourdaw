from pathlib import Path
import urllib.request,json,hashlib,base64,tarfile,io,sys
root=Path(__file__).parent
if len(sys.argv)!=2:raise SystemExit('Pass an external runtime-assets cache directory')
cache=Path(sys.argv[1]).resolve();cache.mkdir(parents=True,exist_ok=True)
record=json.loads((root/'provenance/input-record.json').read_text())['npm']['dist']
archive=cache/'faustwasm-0.20.2.tgz'
b=archive.read_bytes() if archive.exists() else urllib.request.urlopen(record['tarball']).read()
assert 'sha512-'+base64.b64encode(hashlib.sha512(b).digest()).decode()==record['integrity'],'Package integrity mismatch'
archive.write_bytes(b);tar=tarfile.open(fileobj=io.BytesIO(b),mode='r:gz')
for name in ['libfaust-wasm.js','libfaust-wasm.data','libfaust-wasm.wasm']:
 (cache/name).write_bytes(tar.extractfile('package/libfaust-wasm/'+name).read())
print('Verified official0.20.2 package integrity and extracted compiler runtime assets outside source capsule')
