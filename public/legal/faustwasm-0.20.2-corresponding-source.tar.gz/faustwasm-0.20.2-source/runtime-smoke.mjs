import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));if(!process.argv[2]||!process.argv[3])throw Error('Pass rebuilt ESM path and verified runtime-assets directory');
const rebuilt=await import(pathToFileURL(path.resolve(process.argv[2])));
const expected=JSON.parse(fs.readFileSync(path.join(root,'provenance/runtime-verification.json'),'utf8'));
const names=Object.keys(rebuilt).sort();if(JSON.stringify(names)!==JSON.stringify(expected.exports))throw Error('Wrong runtime exports');
const assets=path.resolve(process.argv[3]);const mod=await rebuilt.instantiateFaustModuleFromFile(path.join(assets,'libfaust-wasm.js'),path.join(assets,'libfaust-wasm.data'),path.join(assets,'libfaust-wasm.wasm'));
const compiler=new rebuilt.FaustCompiler(new rebuilt.LibFaust(mod));if(compiler.version()!=='2.90.19')throw Error('Wrong compiler');console.log(JSON.stringify({exports:names.length,compilerVersion:compiler.version(),node:process.version,platform:process.platform,arch:process.arch,dspCompilationPerformed:false}));
