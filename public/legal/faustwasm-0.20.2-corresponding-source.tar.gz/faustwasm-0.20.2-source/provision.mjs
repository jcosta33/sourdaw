import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root=path.dirname(fileURLToPath(import.meta.url));const manifest=JSON.parse(fs.readFileSync(path.join(root,'SOURCE-MANIFEST.json'),'utf8'));const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
for(const [relative,entry] of Object.entries(manifest.files)){const bytes=fs.readFileSync(path.join(root,relative));if(hash(bytes)!==entry.sha256||bytes.length!==entry.bytes)throw Error('Source input tampered: '+relative);}
const lock=JSON.parse(fs.readFileSync(path.join(root,'package-lock.json'),'utf8'));
for(const [key,row] of Object.entries(lock.packages)){if(!key)continue;if(!row.resolved.startsWith('https://registry.npmjs.org/')||!row.integrity.startsWith('sha512-'))throw Error('Unpinned dependency: '+key);if(key.startsWith('node_modules/@esbuild/')&&row.version!=='0.28.2')throw Error('Wrong platform-tool version');}
const args=['ci','--ignore-scripts','--no-audit','--no-fund','--registry=https://registry.npmjs.org'];if(process.argv[2])args.push('--cache',path.resolve(process.argv[2]));
execFileSync('npm',args,{cwd:root,stdio:'inherit'});
for(const record of JSON.parse(fs.readFileSync(path.join(root,'provenance/source-map-records.json'),'utf8'))){
 if(!record.relative.startsWith('node_modules/'))continue;const bytes=fs.readFileSync(path.join(root,record.relative));if(hash(bytes)!==record.sha256)throw Error('Installed dependency preferred source differs: '+record.relative);
}
console.log('Verified all capsule inputs and installed exact official dependency closure without scripts');
